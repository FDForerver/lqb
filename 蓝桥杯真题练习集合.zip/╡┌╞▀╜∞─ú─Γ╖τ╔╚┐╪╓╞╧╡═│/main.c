#include "reg52.h"
#include "onewire.h"


/*===========================================================
Date:2022.1.27
Author:С��ͬѧ
Version:1.0
============================================================*/

sbit S7 = P3^0;
sbit S6 = P3^1;
sbit S5 = P3^2;
sbit S4 = P3^3;

sbit Led1 = P0^0;
sbit Led2 = P0^1;
sbit Led3 = P0^2;

unsigned char work_mode = 0,time_mode = 0,time = 0;//����ģʽ  ����ʱ��ģʽ		����ʱ
unsigned char Temperature = 0;//�¶ȼ�¼
unsigned char pwm_duty = 20;
unsigned char count = 0;//��ʱ��1s��ʱ
unsigned char work_or_time = 1;	//����ģʽ��ʱ��ģʽ���л�
unsigned char pwm_start = 1,t = 0;//pwm��ʼ��־

unsigned char code smg_duan[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,
 																0xf8,0x80,0x90,0xbf,0xff};

//-----------------------------����ʱ����-------------------
void Delay(unsigned char t)
{
 	while(t--);
}
//----------------------------74HC138-------------------------
void Init_74HC138(unsigned char n)
{
 	switch(n)
	{
		case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
	}
}
//-------------------------ϵͳ��ʼ��------------------------
void InitSystem(void)
{
 	Init_74HC138(4);
	P0 = 0xff;
	Init_74HC138(5);
	P0 = 0x00;
}
//------------------------����ܰ�λ��ʾ----------------------
void SMG_DisplayBit(unsigned char pos ,unsigned char dat)
{
 	Init_74HC138(6);
	P0 = (0x01 << pos);
	Init_74HC138(7);
	P0 = dat;
}
//-------------------------�������ʾ-------------------------
void SMG_Close(void)
{
 	Init_74HC138(6);
	P0 = 0xff;
	Init_74HC138(7);
	P0 = 0xff;
}

//�¶���ʾ
void SMG_Display_Temperature(void)
{
	SMG_DisplayBit(0,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(1,smg_duan[4]);
	Delay(200);
	SMG_DisplayBit(2,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(3,smg_duan[11]);
	Delay(200);
	SMG_DisplayBit(4,smg_duan[11]);
	Delay(200);
	SMG_DisplayBit(5,smg_duan[Temperature/10%10]);
	Delay(200);
	SMG_DisplayBit(6,smg_duan[Temperature%10]);
	Delay(200);
	SMG_DisplayBit(7,0xc6);		 // C ->0110 0011 0xc6
	Delay(200);
	SMG_Close();
	Delay(200);
}

//����ܲ��Ժ���
void SMG_Display(void)
{
	SMG_DisplayBit(0,smg_duan[0]);
	Delay(200);
	SMG_DisplayBit(1,smg_duan[1]);
	Delay(200);
	SMG_DisplayBit(2,smg_duan[2]);
	Delay(200);
	SMG_DisplayBit(3,smg_duan[3]);
	Delay(200);
	SMG_DisplayBit(4,smg_duan[4]);
	Delay(200);
	SMG_DisplayBit(5,smg_duan[5]);
	Delay(200);
	SMG_DisplayBit(6,smg_duan[6]);
	Delay(200);
	SMG_DisplayBit(7,smg_duan[7]);
	Delay(200);
	SMG_Close();
	Delay(200);
}

//ʱ����ʾ
void SMG_Display_Time(void)
{
	SMG_DisplayBit(0,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(1,smg_duan[work_mode]);
	Delay(200);
	SMG_DisplayBit(2,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(3,smg_duan[11]);
	Delay(200);
	SMG_DisplayBit(4,smg_duan[11]);
	Delay(200);
	SMG_DisplayBit(5,smg_duan[time/100]);
	Delay(200);
	SMG_DisplayBit(6,smg_duan[time/10%10]);
	Delay(200);
	SMG_DisplayBit(7,smg_duan[time%10]);
	Delay(200);
	SMG_Close();
	Delay(200);
}
//-------------------------------�¶Ȼ�ȡ-------------------
void  Read_Temperature(void)
{
 	unsigned char LSB,MSB;
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
	Delay(500);
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	LSB = Read_DS18B20();
	MSB = Read_DS18B20();
	Temperature = (MSB << 8) | LSB;
	Temperature = Temperature >> 4;//ֻ��������
}
//-----------------------------����ɨ��---------------------
void Key_Scans(void)
{
	//S4����Ϊ����ģʽ�л�����->˯�߷磨0�� ->��Ȼ�磨1�� ->���磨2�� 
	if(S4 == 0)
	Delay(20);
	if(S4 == 0)
	{
		 while(S4 == 0)
		 {
				if(work_mode == 0)
				{
					work_mode = 1;
					pwm_duty = 20;
				}
				else if(work_mode == 1)
				{
					work_mode = 2;
					pwm_duty = 30;
				}
				else if(work_mode == 2)
				{
				 	work_mode = 0;
					pwm_duty = 70;
				}
				SMG_Display_Time();
		 }
	}

	//S5����Ϊ����ʱ������ÿ�ΰ���S5����ʱʱ������1����	
	//ʣ�๤��ʱ������Ϊ��ǰ��ʱʱ�䣬���¿�ʼ����ʱ
	if(S5 == 0)
	{
	 	Delay(20);
		if(S5 == 0)
		{
			ET1  = 1;
			TR1  = 1;	
			pwm_start = 1;
		 	while(S5 == 0)
			{
			 
			 	if(time_mode == 0)
				{
					time = 0;
					time_mode = 1;
				}
				
				else if(time_mode == 1)
				{
				 	time_mode = 2;
					time = 60;
				}
				else if(time_mode == 2)
				{
				 	time_mode = 0;
					time = 120;
				}
				SMG_Display_Time();
			}
		}
	}
	if(S6 == 0)
	{
	 	Delay(20);
		if(S6 == 0)
		{
		 	while(S6 == 0)
			{
				TR1 = 0;
				pwm_start = 0;
				time = 0;
			}
		}
	}

	if(S7 == 0)
	{
	 	Delay(20);
		if(S7 == 0)
		{
		 	while(S7 == 0)
			{
			 	if(work_or_time == 1)
				{
					work_or_time = 0;
					SMG_Display_Temperature();
				}
				else if(work_or_time == 0)
				{
				 	work_or_time = 1;
					SMG_Display_Time();
				}

			}
		}
	}
}
//-----------------------------��ʱ����ʼ��------------------
void Init_Timer(void)
{
 	TMOD = 0x11;
	TH0  = (65535-100)/256;//1us 1Khz 
	TL0  = (65535-100)%256;
	
	TH1  = (65535-50000)/256;//1us 1Khz 
	TL1  = (65535-50000)%256;						
	ET0  = 1;
	EA   = 1;
	TR0  = 1;
	ET1  = 0;
	TR1  = 0;	
}
//-------------------------������----------------------------
void main(void)
{
	InitSystem();
	Init_Timer();
 	while(1)
	{
		Read_Temperature();
		Key_Scans();
		if(work_or_time == 1)
		{
				 SMG_Display_Time();
		}
		else
		{
				SMG_Display_Temperature();
		}
		if(pwm_start ==  0)
		{
		 	Init_74HC138(4);
			P0 = 0xff;
		}
		//SMG_Display_Temperature();
	}
}
//----------------------�жϷ���-------------------------------
void Server_Timer0() interrupt 1
{
 	TH0  = (65535-100)/256;//1us
	TL0  = (65535-100)%256;
	if(pwm_start == 1)
	{
		t++;
		Init_74HC138(4);
		if(t < pwm_duty)
		{
			if(work_mode == 0)
			{
			 	P0 = 0xfe;
			}					
			else if(work_mode == 1)
			{
			 	P0 = 0xfd;
			}					
			else  if(work_mode == 2)
			{
			 	P0 = 0xfb;
			}																			 
		}	 
		else if(t == 100)
		{
			t = 0;
			P0 = 0xff;
		}	
		
	}
}

void Server_Timer1() interrupt 3
{
	TH1  = (65535-50000)/256;//50ms 
	TL1  = (65535-50000)%256;	
	count++;
	if(count == 20) //1s
	{
		time--;
		count = 0;
		if(time == 0)
		{
		 	pwm_start = 0;
			time = 0;
		}
	}
}
