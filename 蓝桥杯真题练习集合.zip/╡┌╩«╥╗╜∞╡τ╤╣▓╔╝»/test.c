					 #include "reg52.h"
#include "iic.h"

sfr P4 = 0xC0;

sbit R1 = P3^0;
sbit R2 = P3^1;
sbit R3 = P3^2;
sbit R4 = P3^3;
sbit C1 = P4^4;
sbit C2 = P4^2;
sbit C3 = P3^5;	
sbit C4 = P3^4;	

sbit L1 = P0^0;
sbit L2 = P0^1;
sbit L3 = P0^2;
unsigned int count_L1 = 0;   //L1����
bit L1_flag = 0;			 //L1������־λ
unsigned char mode_s12 = 0;  //S12����ģʽ
unsigned int dat_rb2 = 0;    //rb2��ֵ
unsigned int dat_v = 0;      //��ѹ����
int dat_set = 200;  //��ѹ��������
unsigned int count = 0;     //��������
unsigned char code SMG_duama[18]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x88,0x80,0xc6,0xc0,0x86,0x8e,0xbf,0x7f};//����ܶ��벻��С����
unsigned char code SMG_DOT[10] ={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};//����ܶ����С����
bit dat_v_pflag = 0;         //0��ʾdat_vΪû�д���dat_set
unsigned char invalid_key = 0;  //��Ч��������

//==============================================
void Delay(unsigned int t)
{
	while(t--);
}
void SelectHC573(unsigned char channel)
{
	switch(channel)
	{
		case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;	
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break;
	}
}
void DisplaySMG_Bit(unsigned char value,unsigned char pos)
{
	SelectHC573(7);
	P0 = 0xff;
	SelectHC573(6);
	P0 = 0x01 << pos;
	SelectHC573(7);
	P0 = value;
	SelectHC573(0);
}
void CloseALL()
{
	SelectHC573(6);
	P0 = 0xff;
	SelectHC573(7);
	P0 = 0xff;
}
//=============================================

//==========��ʱ�����жϷ�����===============
void InitTimer0()
{
	TMOD = 0x01;
	TH0 = (65535 - 10000) / 256;
	TL0 = (65535 - 10000) % 256;
	
	EA = 1;
	ET0 = 1;
}
void ServiceTimer0() interrupt 1
{
	TH0 = (65535 - 10000) / 256;
	TL0 = (65535 - 10000) % 256;
	
	count_L1++;
	if(count_L1 >= 500)
	{
		count_L1 = 0;
		L1_flag = 1;
		TR0 = 0;
	}
}
//=============================================

//==========24C02��غ���======================
void Write_24C02(unsigned char addr,unsigned char dat)
{
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	IIC_SendByte(dat);
	IIC_WaitAck();
	IIC_Stop();
}
unsigned char Read_24C02(unsigned char addr)
{
	unsigned char temp;
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	
	IIC_Start();
	IIC_SendByte(0xa1);
	IIC_WaitAck();
	temp = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	return temp;
}
//=============================================

//==========ADC��ѹ�������====================
void Read_rb2()
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x43);
	IIC_WaitAck();
	IIC_Stop();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	dat_rb2 = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
}
//=============================================

//==========�������ʾ����=====================
void Display_v()//rb2�����ѹ��ʾ����
{
	DisplaySMG_Bit(0xc1,0);Delay(500);
	DisplaySMG_Bit(0xff,1);Delay(500);
	DisplaySMG_Bit(0xff,2);Delay(500);
	DisplaySMG_Bit(0xff,3);Delay(500);
	DisplaySMG_Bit(0xff,4);Delay(500);
	DisplaySMG_Bit(SMG_DOT[dat_v / 100],5);Delay(500);
	DisplaySMG_Bit(SMG_duama[(dat_v / 10) % 10],6);Delay(500);
	DisplaySMG_Bit(SMG_duama[dat_v % 10],7);Delay(500);
	CloseALL();
}
void Display_set()//��ѹ������ʾ����
{
	DisplaySMG_Bit(0x8c,0);Delay(500);
	DisplaySMG_Bit(0xff,1);Delay(500);
	DisplaySMG_Bit(0xff,2);Delay(500);
	DisplaySMG_Bit(0xff,3);Delay(500);
	DisplaySMG_Bit(0xff,4);Delay(500);
	DisplaySMG_Bit(SMG_DOT[dat_set / 100],5);Delay(500);
	DisplaySMG_Bit(SMG_duama[(dat_set / 10) % 10],6);Delay(500);
	DisplaySMG_Bit(SMG_duama[dat_set % 10],7);Delay(500);
	CloseALL();
}
void Display_count()//������ʾ
{
	DisplaySMG_Bit(0x89,0);Delay(500);
	DisplaySMG_Bit(0xff,1);Delay(500);
	DisplaySMG_Bit(0xff,2);Delay(500);
	DisplaySMG_Bit(0xff,3);Delay(500);
	DisplaySMG_Bit(0xff,4);Delay(500);
	if(count > 99)
	{
		DisplaySMG_Bit(SMG_duama[(count / 100) % 10],5);Delay(500);
	}
	if(count > 9)
	{
		DisplaySMG_Bit(SMG_duama[(count / 10) % 10],6);Delay(500);
	}
	DisplaySMG_Bit(SMG_duama[count % 10],7);Delay(500);
	CloseALL();
}
void Display()//�������ʾ����
{
	if(mode_s12 == 0)
	{
		Read_rb2();
		dat_v = dat_rb2 * 1.961;
		Display_v();
	}
	else if(mode_s12 == 1)
	{
		Display_set();
	}
		
	else if(mode_s12 == 2)
	{
		Display_count();
	}
}
//=============================================

//==============�������ɨ�躯��===============
void ArrayKeyScan()
{
	R4 = 0;
	R2 = R3 = R1 = 1;
	C1 = C2 = C3 = C4 = 1;
	if(C3 == 0)//S12������
	{
		Delay(100);
		if(C3 == 0)
		{
			while(C3 == 0)
			{
				Display();
			}
			if(mode_s12 == 0)
			{
				mode_s12 = 1;
			}
			else if(mode_s12 == 1)
			{
				mode_s12 = 2;
				Write_24C02(0x00,dat_set / 10);
				Delay(1000);
			}
			else if(mode_s12 == 2)
			{
				mode_s12 = 0;
			}

			invalid_key = 0;
		}
	}
	else if(C4 == 0)//S16�����£���
	{
		Delay(100);
		if(C4 == 0)
		{
			while(C4 == 0)
			{
				Display();
			}
			if(mode_s12 == 1)
			{	
				dat_set = dat_set + 50;
				if(dat_set >= 550)
				{
					dat_set = 0;
				}
				invalid_key = 0;	
			}
			else
			{
				invalid_key ++;	
			}
		}
	}
	
	R3 = 0;
	R2 = R4 = R1 = 1;
	C1 = C2 = C3 = C4 = 1;
	if(C3 == 0)//S13�����£���������
	{
		Delay(100);
		if(C3 == 0)
		{
			while(C3 == 0)
			{
				Display();
			}
			if(mode_s12 == 2)
			{
				count = 0;
				invalid_key = 0;
			}
			else
			{
				invalid_key ++;	
			}	
		}
	}
	else if(C4 == 0)//S17�����£���
	{
		Delay(100);
		if(C4 == 0)
		{
			while(C4 == 0)
			{
				Display();
			}
			if(mode_s12 == 1)
			{	
				dat_set = dat_set - 50;
				if(dat_set < 0)
				{
					dat_set = 500;
				}
				invalid_key = 0;	
			}
			else
			{
				invalid_key ++;	
			}
		}
	}
}
//=============================================

//===============����ʾ����====================
void LedRunning ()
{
	SelectHC573(4);
	if(dat_v < dat_set)
	{
		TR0 = 1;
	}
	else
	{
		TR0 = 0;
		count_L1 = 0;
		L1_flag = 0;
	}

	if (L1_flag == 1)
	{
		L1 = 0;
	}
	else
	{
		L1 = 1;	
	}
	
	if ((count % 2 ) == 1)
	{
		L2 = 0;
	}
	else 
	{
		L2 = 1;
	}

	if (invalid_key >= 3)
	{
		L3 = 0;
	}
	else
	{
		L3 = 1;
	}
	SelectHC573(0);	
}
//=============================================


//===========ϵͳ��ʼ������====================
void InitSystem()
{
	SelectHC573(5);
	P0 = 0x00;
	SelectHC573(4);
	P0 = 0xff;
	SelectHC573(0);
}
//=============================================

void main()
{
	InitSystem();
	InitTimer0();
	dat_set = Read_24C02(0x00) * 10;
	while(1)
	{
		Read_rb2();
		dat_v = dat_rb2 * 1.961;
		if (dat_v > dat_set)
		{
			dat_v_pflag = 1;
		}
		else if (dat_v <= dat_set)
		{
			if (dat_v_pflag == 1)
			{
				count++;
				dat_v_pflag = 0;
			}
		}
		Display();
		ArrayKeyScan();
		LedRunning ();
	}
}
//==========================================================
