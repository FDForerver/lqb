 #include "reg52.h"
 #include "iic.h"

 /**************************************************
 *���ű���Ƭ����ʮ����ڶ���ʡ��
 *Auuhor:С��ͬѧ
 *Version:1.0
 **************************************************/

sbit S7 = P3^0;
sbit S6 = P3^1;
sbit S5 = P3^2;
sbit S4 = P3^3;

unsigned long Frequent = 0,Period = 0; //Ƶ�ʱ��� �����ڱ���
unsigned  int Voltage = 325,Rd1 = 0; //��ѹ���� ����ֵ
unsigned char channel_mode = 1; //ͨ������
unsigned char Interface = 0;//����
unsigned int f_count = 0,t_count = 0; //Ƶ�ʼ�ʱ  ��ʱ����
unsigned char code smg_duan[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};
unsigned char code smg_dot[10] ={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};//����ܶ����С����

 //------------------------------����ʱ---------------------------
 void Delay(unsigned int t)
{
 	while(t--);
}

//---------------------------74HC138��ʼ��-------------------------
void Init_74HC138(unsigned char n)
{
 	switch(n)
	{
	 	case 0:P2 = (P2 & 0x1f) | 0x00;break;
		case 4:P2 = (P2 & 0x1f)	| 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
	}
}
//-----------------------------ϵͳ��ʼ��---------------------------
void Init_System(void)
{
 	Init_74HC138(4);
	P0 = 0xff;
	Init_74HC138(5);
	P0 = 0x00;
}
//----------------------------����ܰ�λ����------------------------
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	Init_74HC138(6);
	P0 = (0x01 << pos);
	Init_74HC138(7);
	P0 = dat;
}

//------------------------------�������ʾ����-----------------------
void SMG_Close(void)
{
 	Init_74HC138(6);
	P0 = 0xff;
	Init_74HC138(7);
	P0 = 0xff;
}

//Ƶ����ʾ
void SMG_Display_F(void)
{
	//F -> 0111 0001 -> 0x8e
	SMG_DisplayBit(0,0x8e);
	Delay(200);
	if(Frequent > 999999)
	{
		SMG_DisplayBit(1,smg_duan[Frequent/1000000]);
		Delay(200);
	}
	if(Frequent > 99999)
	{
	  SMG_DisplayBit(2,smg_duan[Frequent/100000%10]);
		Delay(200);
	}
	if(Frequent > 9999)
	{
		SMG_DisplayBit(3,smg_duan[Frequent/10000%10]);
		Delay(200);
	}
	if(Frequent > 999)
	{
	  SMG_DisplayBit(4,smg_duan[Frequent/1000%10]);
		Delay(200);
	}
	if(Frequent > 99)
	{
		SMG_DisplayBit(5,smg_duan[Frequent/100%10]);
		Delay(200);
	}
	if(Frequent > 9)
	{
		SMG_DisplayBit(6,smg_duan[Frequent/10%10]);
		Delay(200);
	}

	SMG_DisplayBit(7,smg_duan[Frequent%10]);
	Delay(200);
	SMG_Close();
	Delay(200);
}

//������ʾ
void SMG_Display_T(void)
{
	Period = (unsigned long)(1.0/(float)Frequent)*1000000.0;
	// 0001 0011 -> 0xc8
	SMG_DisplayBit(0,0xc8);
	Delay(200);
	if(Period > 999999)
	{
		SMG_DisplayBit(1,smg_duan[Period/1000000]);
		Delay(200);
	}
	if(Period > 99999)
	{
	  SMG_DisplayBit(2,smg_duan[Period/100000%10]);
		Delay(200);
	}
	if(Period > 9999)
	{
		SMG_DisplayBit(3,smg_duan[Period/10000%10]);
		Delay(200);
	}
	if(Period > 999)
	{
	  SMG_DisplayBit(4,smg_duan[Period/1000%10]);
		Delay(200);
	}
	if(Period > 99)
	{
		SMG_DisplayBit(5,smg_duan[Period/100%10]);
		Delay(200);
	}
	if(Period > 9)
	{
		SMG_DisplayBit(6,smg_duan[Period/10%10]);
		Delay(200);
	}

	SMG_DisplayBit(7,smg_duan[Period%10]);
	Delay(200);
	SMG_Close();
	Delay(200);
}

//��ѹ��ʾ
void SMG_Display_V(void)
{
	//U -> 1000 0011 -> 0xc1
	SMG_DisplayBit(0,0xc1);
	Delay(200);
	SMG_DisplayBit(1,smg_duan[10]);
		Delay(200);
	if(channel_mode == 3)
	{		
		SMG_DisplayBit(2,smg_duan[channel_mode]);
		Delay(200);
		SMG_DisplayBit(3,0xff);
		Delay(200);
		SMG_DisplayBit(4,0xff);
		Delay(200);
		SMG_DisplayBit(5,smg_dot[Voltage/100]);
		Delay(200);
		SMG_DisplayBit(6,smg_duan[Voltage/10%10]);
		Delay(200);
		SMG_DisplayBit(7,smg_duan[Voltage%10]);
		Delay(200);
	}
	else if(channel_mode == 1)
	{
	 	SMG_DisplayBit(2,smg_duan[channel_mode]);
		Delay(200);
		SMG_DisplayBit(3,0xff);
		Delay(200);
		SMG_DisplayBit(4,0xff);
		Delay(200);
		SMG_DisplayBit(5,smg_dot[Rd1/100]);
		Delay(200);
		SMG_DisplayBit(6,smg_duan[Rd1/10%10]);
		Delay(200);
		SMG_DisplayBit(7,smg_duan[Rd1%10]);
		Delay(200);

	}
	SMG_Close();
	Delay(200);
}

//------------------------------��ʱ����ʼ��------------------------------
void Init_Timer(void)
{
 	TMOD = 0x16; //��ʱ��0���� ��ʱ��1��ʱ				0001 0110
	TH0  = 0xff;
	TL0  = 0xff;
	TH1  = (65535-50000); //50ms
	TL1  = (65535-50000);
	ET0  = 1;
	ET1  = 1;
	TR0  = 1;
	TR1  = 1;
	EA   = 1;
}
//---------------------------------PCF8591-------------------------------
void Read_Rd1(void)
{
 	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x01); //����ֵͨ��
	IIC_WaitAck();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	Rd1 = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
}

void Read_Rd3(void)
{
 	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x03); //ADͨ��
	IIC_WaitAck();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	Voltage = IIC_RecByte();
	Voltage = (unsigned int)(Voltage/255.0)*5.0*100.0; //����100���������
	IIC_SendAck(1);
	IIC_Stop();
}
//---------------------------------��������-------------------------------
void  Key_Scans(void)
{
	//S4������Ϊ�����桱����
 	if(S4 == 0)
	{
	 	Delay(20);
		if(S4 == 0)
		{
		 	while(1)
			{
				if(Interface == 0)
				{
					Interface = 1;
				 	SMG_Display_F();
				}
				else if(Interface == 1)
				{
					Interface = 2;
				//	SMG_Display_T();	
				}
				else if(Interface == 2)
				{
				 	Interface = 0;
					SMG_Display_V();
				}
			}
		}
	}
	if(S5 == 0)
	{
	 	Delay(20);
		if(S5 == 0)
		{	
			if(Interface == 2)  //��ѹ�����½����л�
				{
			 	while(1)
				{
					if(channel_mode == 1)
					{
					 	channel_mode = 3;
						SMG_Display_V();
					}
					else if(channel_mode == 3)
					{
					 	channel_mode = 1;
						SMG_Display_V();
					}
				}
			}
		}
	}

	if(S6 == 0)
	{
	 	Delay(20);
		if(S6 == 0)
		{
		 	while(1)
			{

			}
		}
	}

	if(S7 == 0)
	{
	 	Delay(20);
		if(S7 == 0)
		{
		 	while(1)
			{

			}
		}
	}
}
//-----------------------------------������--------------------------------
void main(void)
{
		Init_System();
		Init_Timer();
		while(1)
		{
			Key_Scans();
			switch(Interface)
			{
				case 0:SMG_Display_F();break;			 //Ƶ����ʾ
				case 1:SMG_Display_T();break;			 //������ʾ
				case 2:SMG_Display_V();break;			 //��ѹ��ʾ
			}	
		}
}
//-----------------------------�жϷ�����---------------------------------
void Server_Timer0() interrupt 1
{
 	f_count++;
}

void Server_Timer1() interrupt 3
{
	TH1  = (65535-50000); //50ms
	TL1  = (65535-50000);
	t_count++;
	if(t_count == 20) //1s
	{
	 	Frequent = f_count;
		f_count = 0;
		t_count = 0;
	}
}