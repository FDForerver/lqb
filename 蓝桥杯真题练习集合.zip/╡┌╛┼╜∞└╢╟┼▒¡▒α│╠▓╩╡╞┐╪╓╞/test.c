# include "reg52.h"
# include "iic.h"
# include "absacc.h"

sbit S7 = P3^0;
sbit S6 = P3^1;
sbit S5 = P3^2;
sbit S4 = P3^3;

unsigned int rb2 = 0;								//��Ŷ�ȡ��Rb2������
unsigned char mode = 1;								//��ˮ��ģʽ
unsigned int interval[4] = {400,400,400,400};		//4��ģʽ��ˮ�Ƶ���ת���
unsigned char bright_grade = 4;		 				//led�Ƶ����ȵȼ�
unsigned char led_mode[24] = {0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f,0x7f,0xbf,0xdf,0xef,0xf7,0xfb,0xfd,0xfe,0x7e,0xbd,0xdb,0xe7,0xe7,0xdb,0xbd,0x7e};		   //24��led��תģʽ
unsigned char duanma[18] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x88,0x80,0xc6,0xc0,0x86,0x8e,0xbf,0x7f};			   //����ֵ
unsigned char led_stat = 0;			 				//ledģʽ��Ӧ������ֵ
unsigned int count = 0;              				//��ʱ��T0�ļ�������
unsigned char k7 = 0;                				//k7�ı�־λ
unsigned char k6 = 0;				 				//k6�ı�־λ
unsigned int smg_c = 0;				 				//��ʱ������ܼ�������
unsigned char smg_f = 0;			 				//�������˸��־����
unsigned char pwm_t = 100;			 				//����ռ�ձ�
unsigned int pwm_c = 0;				 				//������������
unsigned char pwm_f = 1;			 				//�������־����

void ExecuteRb2 ();
void LEDRunning ();

//======================��ʼ������=========================
void InitSystem()
{
	XBYTE[0x8000] = 0xff;
	XBYTE[0xa000] = 0x00;
}
//=========================================================

//====================24C02���ݶ�д����====================
unsigned char Read24C02(unsigned char addr)
{
	unsigned char tmp;

	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	
	IIC_Start();
	IIC_SendByte(0xa1);
	IIC_WaitAck();
	tmp = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	
	return tmp;	
}

void Write24C02 (unsigned char addr,unsigned char dat)
{
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	IIC_SendByte(dat);
	IIC_WaitAck();
	IIC_Stop();		
}
//=========================================================

//====================��ȡRb2��λ����ֵ====================
void Readrb2 ()
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x03);
	IIC_WaitAck();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	rb2 = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();	
}
//=========================================================

//=====================�������ʾ����======================
void ShowSMG_bit (unsigned char pos,unsigned char dat)
{
	XBYTE[0xc000] = 0x01 << pos - 1;
	XBYTE[0xe000] = dat;
}

void Delay_SMG (unsigned int t)
{
	while (t--);	
}

void AllSMG(unsigned char dat)
{
	XBYTE[0xe000] = 0xff;
	XBYTE[0xc000] = 0xff;
	XBYTE[0xe000] = dat;	
}

void ShowSMG_M ()
{
	ShowSMG_bit(1,duanma[16]);
	Delay_SMG(500);
	if (((k6 == 1) & (smg_f == 1)) | (k6 == 0) | (k6 == 2))
	{
		ShowSMG_bit(2,duanma[mode]);
		Delay_SMG(500);		
	}
	ShowSMG_bit(3,duanma[16]);
	Delay_SMG(500);
	ShowSMG_bit(4,0xff);
	Delay_SMG(500);
	if (((k6 == 2) & (smg_f == 1)) | (k6 == 0) | (k6 == 1))
	{
		if (interval[mode - 1] > 999)
		{
			ShowSMG_bit(5,duanma[interval[mode - 1] / 1000]);
			Delay_SMG(500);	
		}
		ShowSMG_bit(6,duanma[(interval[mode - 1] / 100) % 10]);
		Delay_SMG(500);
		ShowSMG_bit(7,duanma[(interval[mode - 1] / 10) % 10]);
		Delay_SMG(500);
		ShowSMG_bit(8,duanma[interval[mode - 1] % 10]);
		Delay_SMG(500);		
	}
	AllSMG(0xff);
}

void ShowSMG_L ()
{
	ShowSMG_bit(1,0xff);
	Delay_SMG(500);
	ShowSMG_bit(2,0xff);
	Delay_SMG(500);	
	ShowSMG_bit(3,0xff);
	Delay_SMG(500);
	ShowSMG_bit(4,0xff);
	Delay_SMG(500);
	ShowSMG_bit(5,0xff);
	Delay_SMG(500);	
	ShowSMG_bit(6,duanma[16]);
	Delay_SMG(500);
	ShowSMG_bit(7,duanma[bright_grade]);
	Delay_SMG(500);
	ShowSMG_bit(8,duanma[16]);
	Delay_SMG(500);
	AllSMG(0xff);
}
//=========================================================

//=====================��ʱ��T0 100us======================
void InitTime0 ()
{
	TMOD = 0x01;

	TH0 = (65535 - 100) / 256;
	TL0 = (65535 - 100) % 256;

	ET0 = 1;
	EA = 1;
	TR0 = 1;
}

void ServiceTime0 () interrupt 1
{
	TH0 = (65535 - 100) / 256;
	TL0 = (65535 - 100) % 256;

	if (k7 == 1)
	{
		count++;	
	}
	if (count >= (interval[mode - 1] * 10))
	{
		led_stat++;
		count = 0;
	}

	smg_c++;
	if (smg_c >= 5000)
	{
		smg_c = 0;
		if (smg_f == 0)
		{
			smg_f = 1;
		}
		else if (smg_f == 1)
		{
			smg_f = 0;
		}
	}

	pwm_c++;
	if (pwm_c >= pwm_t)
	{
		pwm_f = 0;
		if (pwm_c >= 100)
		{
			pwm_c = 0;
			pwm_f = 1;	
		}
	}
}
//=========================================================

//=====================�������============================
void Delay_Key (unsigned char t)
{
	while (t--);
}

void ScanKey ()
{
	if (S7 == 0)
	{
		Delay_Key(100);
		if (S7 == 0)
		{
			while(S7 == 0)
			{
				ShowSMG_M ();
			}
			if (k7 == 0)
			{
				k7 = 1;
			}
			else if (k7 == 1)
			{
				k7 = 0;	
			}
		}	
	}
	else if (S6 == 0)
	{
		Delay_Key(100);
		if (S6 == 0)
		{
			while(S6 == 0)
			{
				ShowSMG_M ();	
			}
			if (k6 == 0)
			{
				k6 = 1;
			}
			else if (k6 == 1)
			{
				k6 = 2;
			}
			else if (k6 == 2)
			{
				k6 = 0;
			}
		}	
	}
	else if (S5 == 0)
	{
		Delay_Key(100);
		if (S5 == 0)
		{
			while(S5 == 0)
			{
				ShowSMG_M ();
			}
			if (k6 == 1)
			{
				mode++;
				if (mode >= 4)
				{
					mode = 4;
				}
			}
			else if (k6 == 2)
			{
				interval[mode - 1] = interval[mode - 1] + 100;
				if (interval[mode - 1] >= 1200)
				{
					interval[mode - 1] = 1200;
				}
				if (mode == 1)
				{
					Write24C02(0x00,interval[mode - 1] / 10);	
				}
				else if (mode == 2)
				{
					Write24C02(0x01,interval[mode - 1] / 10);	
				}
				else if (mode == 3)
				{
					Write24C02(0x02,interval[mode - 1] / 10);	
				}
				else if (mode == 4)
				{
					Write24C02(0x03,interval[mode - 1] / 10);	
				}
			}
		}	
	}
	else if (S4 == 0)
	{
		Delay_Key(100);
		if (S4 == 0)
		{
			if (k6 == 0)
			{
				while(S4 == 0)
				{
					ExecuteRb2 ();
					LEDRunning ();
					ShowSMG_L ();	
				}	
			}
			else if (k6 == 1)
			{
				while(S4 == 0)
				{
					ShowSMG_M ();	
				}
				mode = mode -1;
				if (mode <=1)
				{
					mode = 1;
				}
			}
			else if (k6 == 2)
			{
				while(S4 == 0)
				{
					ShowSMG_M ();	
				}
				interval[mode - 1] = interval[mode - 1] - 100;
				if (interval[mode - 1] <= 400)
				{
					interval[mode - 1] = 400;
				}
				if (mode == 1)
				{
					Write24C02(0x00,interval[mode - 1] / 10);	
				}
				else if (mode == 2)
				{
					Write24C02(0x01,interval[mode - 1] / 10);	
				}
				else if (mode == 3)
				{
					Write24C02(0x02,interval[mode - 1] / 10);	
				}
				else if (mode == 4)
				{
					Write24C02(0x03,interval[mode - 1] / 10);	
				}
			}
		}	
	}
}
//=========================================================

//=======================LED����===========================
void LEDRunning ()
{
	if (mode == 1)
	{
		if (led_stat > 7)
		{
			led_stat = 0;
		}
		if (pwm_f == 1)
		{
			XBYTE[0x8000] = led_mode[led_stat];	
		}
		else if (pwm_f == 0)
		{
			XBYTE[0x8000] = 0xff;	
		}
	}
	else if (mode == 2)
	{
		if (led_stat < 8 | led_stat > 15)
		{
			led_stat = 8;
		}
		if (pwm_f == 1)
		{
			XBYTE[0x8000] = led_mode[led_stat];	
		}
		else if (pwm_f == 0)
		{
			XBYTE[0x8000] = 0xff;	
		}
	}
	else if (mode == 3)
	{
		if (led_stat < 16 | led_stat > 19)
		{
			led_stat = 16;
		}
		if (pwm_f == 1)
		{
			XBYTE[0x8000] = led_mode[led_stat];	
		}
		else if (pwm_f == 0)
		{
			XBYTE[0x8000] = 0xff;	
		}
	}
	else if (mode == 4)
	{
		if (led_stat < 20 | led_stat > 23)
		{
			led_stat = 20;
		}
		if (pwm_f == 1)
		{
			XBYTE[0x8000] = led_mode[led_stat];	
		}
		else if (pwm_f == 0)
		{
			XBYTE[0x8000] = 0xff;	
		}
	}
}
//=========================================================

//=====================����rb2��ֵ=========================
void ExecuteRb2 ()
{
	Readrb2 ();
	if (rb2 <= 60)
	{
		bright_grade = 1;
		pwm_t = 25;	
	}
	else if ((rb2 > 60) & (rb2 <= 120))
	{
		bright_grade = 2;
		pwm_t = 50;	
	}
	else if ((rb2 > 120) & (rb2 <= 180))
	{
		bright_grade = 3;
		pwm_t = 75;	
	}
	else if (rb2 > 180)
	{
		bright_grade = 4;
		pwm_t = 100;	
	}
}
//=========================================================

//========================������===========================
void main (void)
{
	InitSystem();
	interval[0] = Read24C02(0x00) * 10;
	interval[1] = Read24C02(0x01) * 10;
	interval[2] = Read24C02(0x02) * 10;
	interval[3] = Read24C02(0x03) * 10;
	InitTime0 ();
	while (1)
	{
		ExecuteRb2 ();
		ScanKey ();
		if (k7 == 1)
		{
			LEDRunning ();	
		}
		else if (k7 == 0)
		{
			XBYTE[0x8000] = 0xff;
		}
		ShowSMG_M ();	
	}
}
//=========================================================
                       