#include "reg52.h"
#include "iic.h"

/*==========================================================
Date:2022.1.30
Author:С��ͬѧ
Version:1.1
===========================================================*/
sbit S7 = P3^0;
sbit S6 = P3^1;
sbit S5 = P3^2;
sbit S4 = P3^3;

unsigned char Rd2 = 0;			//��¼��ѹֵ
unsigned char k7 = 0,k6 = 0; //S6 S7���±�־λ
unsigned char count = 0,smg_flash = 0,smg_flag = 0;//����  �����0.8s��˸ ������־
unsigned char work_mode = 1,mode_or_time = 0; //led����ģʽ  ģʽ��ʱ����ת�����л�
unsigned char led_start = 0;//led_start ->0 ֹͣ  led_start->1 ����
unsigned char Led_Level = 4;//�ƹ�ȼ�
unsigned char interval[] = {400,400,400,400}; //400-1200
unsigned char smg_duan[18] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x88,0x80,0xc6,0xc0,0x86,0x8e,0xbf,0x7f};			   //����ֵ
unsigned char led_mode[24] = {0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f,0x7f,0xbf,0xdf,0xef,0xf7,0xfb,0xfd,0xfe,0x7e,0xbd,0xdb,0xe7,0xe7,0xdb,0xbd,0x7e};		   //24��led��תģʽ

//------------------------------����ʱ--------------------
void Delay(unsigned char t)
{
 	while(t--);
}
//------------------------------74HC138----------------------
void Init_74HC138(unsigned char n)
{
 	switch(n)
	{
	 	case 4:P2 = (P2 & 0x1f)	| 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
	}
}
//------------------------ϵͳ��ʼ��-------------------------
void 	Init_System(void)
{
 	Init_74HC138(4);
	P0 = 0xff;
	Init_74HC138(5);
	P0 = 0x00;
}
//----------------------------����ܰ�λ����----------------
void SMG_DisplayBit(unsigned char pos ,unsigned char dat)
{
 	Init_74HC138(6);
	P0 = (0x01 << pos);
	Init_74HC138(7);
	P0 = dat;
}

void SMG_Close(void)
{
 	Init_74HC138(6);
	P0 = 0xff;
	Init_74HC138(7);
	P0 = 0xff;
}
//----------------------Rd2��ѹ��ȡ------------------------
void Read_Rd2(void)
{
 	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x03);
	IIC_WaitAck();

	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	Rd2 = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
}
//--------------------------AT24C02------------------------
void Write_AT24C02(unsigned char addr,unsigned char dat)
{
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	IIC_SendByte(dat);
	IIC_WaitAck();
	IIC_Stop();
}

unsigned char Read_AT24C02(unsigned char addr)
{
	unsigned char temp;
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();

	IIC_Start();
	IIC_SendByte(0xa1);
	IIC_WaitAck();
	temp = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	return temp;
}
//----------------------------��ʱ����ʼ��------------------
void Init_Timer(void)
{
 	TMOD = 0x01;
	TH0  = (65535-100)/256; //100uS
	TL0  = (65535-100)%256;
	ET0  = 1;
	TR0  = 1;
	EA   = 1;
}
//--------------------------�������ʾ����------------------
void SMG_Display(void)
{
 	SMG_DisplayBit(0,0xbf);
	Delay(200);																
	Delay(200);
	SMG_DisplayBit(1,smg_duan[work_mode-1]);
	SMG_DisplayBit(2,0xbf);
	Delay(200);
	SMG_DisplayBit(3,0xff);
	Delay(200);
	if(interval[work_mode-1] > 999)
	{
	 SMG_DisplayBit(4,smg_duan[interval[work_mode-1]/1000]);
	 Delay(200);
	}
	if(interval[work_mode-1] > 99)
	{
	 SMG_DisplayBit(5,smg_duan[interval[work_mode-1]/100%10]);
	 Delay(200);
	}
	if(interval[work_mode-1] > 9)
	{
	 SMG_DisplayBit(6,smg_duan[interval[work_mode-1]/10%10]);
	 Delay(200);
	}
	 SMG_DisplayBit(7,smg_duan[interval[work_mode-1]%10]);
	Delay(200);
	SMG_Close();
	Delay(200);
}
//ģʽ����
void SMG_Display_Mode(void)
{
	SMG_DisplayBit(0,0xbf);
	Delay(200);
	if(smg_flash == 0)
	{
		SMG_DisplayBit(1,smg_duan[work_mode-1]);
		Delay(200);
	}
	else
	{
	  SMG_DisplayBit(1,0xff);
		Delay(200);
	}
	SMG_DisplayBit(2,0xbf);
	Delay(200);
	SMG_DisplayBit(3,0xff);
	Delay(200);
	if(interval[work_mode-1] > 999)
	{
	 SMG_DisplayBit(4,smg_duan[interval[work_mode-1]/1000]);
	 Delay(200);
	}
	if(interval[work_mode-1] > 99)
	{
	 SMG_DisplayBit(5,smg_duan[interval[work_mode-1]/100%10]);
	 Delay(200);
	}
	if(interval[work_mode-1] > 9)
	{
	 SMG_DisplayBit(6,smg_duan[interval[work_mode-1]/10%10]);
	 Delay(200);
	}
	SMG_DisplayBit(7,smg_duan[interval[work_mode-1]%10]);
	Delay(200);
	SMG_Close();
	Delay(200);
}

//��תʱ������
void SMG_Display_Time(void)
{
	SMG_DisplayBit(0,0xbf);
	Delay(200);
	SMG_DisplayBit(1,smg_duan[work_mode-1]);
	Delay(200);
	SMG_DisplayBit(2,0xbf);
	Delay(200);
	SMG_DisplayBit(3,0xff);
	Delay(200);
	if(smg_flash == 0)
	{
		if(interval[work_mode-1] > 999)
		{
		 SMG_DisplayBit(4,smg_duan[interval[work_mode-1]/1000]);
		 Delay(200);
		}
		if(interval[work_mode-1] > 99)
		{
		 SMG_DisplayBit(5,smg_duan[interval[work_mode-1]/100%10]);
		 Delay(200);
		}
		if(interval[work_mode-1] > 9)
		{
		 SMG_DisplayBit(6,smg_duan[interval[work_mode-1]/10%10]);
		 Delay(200);
		}
		SMG_DisplayBit(7,smg_duan[interval[work_mode-1]%10]);
		Delay(200);
	}
	else
	{
		SMG_DisplayBit(4,0xff);
		Delay(200);
		SMG_DisplayBit(5,0xff);
		Delay(200);
		SMG_DisplayBit(6,0xff);
		Delay(200);
		SMG_DisplayBit(7,0xff);
		Delay(200);
	}
	SMG_Close();
	Delay(200);
}

void SMG_Display_Level(void)
{
 	SMG_DisplayBit(0,0xff);
	Delay(200);																
	SMG_DisplayBit(1,0xff);
	SMG_DisplayBit(2,0xff);
	Delay(200);
	SMG_DisplayBit(3,0xff);
	Delay(200);
	SMG_DisplayBit(4,0xff);
	Delay(200);																
	Delay(200);
	SMG_DisplayBit(5,0xff);
	SMG_DisplayBit(6,0xbf);
	Delay(200);
	SMG_DisplayBit(7,smg_duan[Led_Level]);
	Delay(200);
	SMG_Close();
	Delay(200);
}
//------------------------��������--------------------------
void Key_Scans(void)
{
	//Led ��ת����ֹͣ
 	if(S7 == 0)
	{
	 	Delay(20);
		if(S7 == 0)
		{
		 	while(S7 == 0)
			{
				if(mode_or_time == 0)
				{
				 	SMG_Display();
				}
				else if(mode_or_time == 1)
				{
				 	SMG_Display_Mode();
				}
				else if(mode_or_time == 2)
				{
				 	SMG_Display_Time();
				}
			}
			//led_start ->0 ֹͣ  led_start->1 ����
			if(led_start == 0)
			{
			 	led_start = 1;
			}
			else if(led_start == 1)
			{
			 	led_start = 0;
			}
		}
	}

	//ledģʽ����ת�����л�
	if(S6 == 0)
	{
	 	Delay(20);
		if(S6 == 0)
		{
		 	mode_or_time++;
			while(S6 == 0)
			{
			 	if(mode_or_time == 1)
				{
				 	SMG_Display_Mode();
				}
				else if(mode_or_time > 2)
				{
				 	SMG_Display_Time();
					mode_or_time = 0;
				}
				else
				{
					 SMG_Display();
				}
			}
		}
	}
}
//--------------------------������--------------------------
void main(void)
{
	Init_System();
	Init_Timer();
 	while(1)
	{
			Key_Scans();
			SMG_Display_Level();
			/*
			switch(mode_or_time)
			{
				case 1:SMG_Display_Mode();break;
				case 2:SMG_Display_Time();break;
			}
			*/
	}
}
//------------------------------�жϷ���---------------------
void Server_Timer0() interrupt 1
{
 	TH0  = (65535-100)/256; //100uS
	TL0  = (65535-100)%256;
	smg_flag++;
	if(smg_flag == 8000)		//0.8S
	{
	 	smg_flag = 0;
		smg_flash = ~smg_flash;
	}
}