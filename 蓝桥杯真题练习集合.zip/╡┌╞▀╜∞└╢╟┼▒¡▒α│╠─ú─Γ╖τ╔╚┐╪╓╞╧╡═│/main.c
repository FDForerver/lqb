#include "reg52.h"
#include "onewire.h"
#include "absacc.h"

/********************************************
Date:2022-1-17
Author:С��ͬѧ
Learn From:B վС�۷���ʦ
*********************************************/

sbit S4 = P3^3;
sbit S5 = P3^2;
sbit S6 = P3^1;
sbit S7 = P3^0;

unsigned char Temp; //����¶�
unsigned char work_mode = 1; //����ģʽ
unsigned char pwm = 0;			 //�Ƚ�ֵ
unsigned char pwm_duty = 20;
unsigned char pwm_num[]  = {20,30,70}; //ռ�ձ�
unsigned char work_time[] = {0,60,120}; //����ʱ��
unsigned char work_or_time = 1; //����ģʽ�����¶ȶ�ȡ
unsigned char num = 0; // ʱ��ģʽ
unsigned char time_value = 0;//ʵʱʱ���¼
unsigned char pwm_start = 1; //S9������¼ֵ ���ʱ�� pwmֹͣ
unsigned char led_value[3] = {0xfe,0xfd,0xfb}; //��ͬ����ģʽ������ͬled
unsigned int count = 0;//��¼��ʱʱ�� 1S
//������Ŀ�ܶ���
//0-f  0xbf���� -
unsigned char code SMG_Duan[] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,
															   0x80,0x90,0x88,0x83,0xC6,0xA1,0x86,0x8E,0xbf};


//--------------------------------����ʱ����---------------------------
void Delay(unsigned int t)
{
 	while(t--);
}


//-----------------------------------ϵͳ��ʼ��----------------------------
void InitSystem(void)
{
 	XBYTE[0x8000] = 0xff; //�ر�led
	XBYTE[0xa000] = 0x00;  //�رռ̵����ͷ�����
}
//-----------------------------------����ܰ�λ����------------------------
void SMG_DisplayBit(unsigned  char pos ,unsigned char dat)
{
 	 XBYTE[0xc000] = (0x01 <<pos);
	 XBYTE[0xe000] = dat;
}

//�ر����������
void SMG_Close(unsigned char dat)
{
 	 	XBYTE[0xc000] = 0xff;
		XBYTE[0xe000] = dat;
}
//--------------------------------------�������ʾ-------------------------
void SMG_DisplayTemp_Data(void)
{
 		SMG_DisplayBit(0,SMG_Duan[16]);
		Delay(200);
		SMG_DisplayBit(2,SMG_Duan[16]);
		Delay(200);
		SMG_DisplayBit(3,0xff);
		Delay(200);
		if(work_or_time == 1)		  //Ϊ����ģʽ
		{
			SMG_DisplayBit(1,SMG_Duan[work_mode]);
			Delay(200);
			SMG_DisplayBit(4,0xff);
			Delay(200);
			SMG_DisplayBit(5,SMG_Duan[time_value/100]);
			Delay(200);							  
			SMG_DisplayBit(6,SMG_Duan[time_value/10%10]);
			Delay(200);
			SMG_DisplayBit(7,SMG_Duan[time_value%10]);
			Delay(200);
		}
		else	 //Ϊ��ʱģʽ

		{
			SMG_DisplayBit(1,SMG_Duan[4]);
			Delay(200);
			SMG_DisplayBit(4,0xff);
			Delay(200);
			SMG_DisplayBit(5,SMG_Duan[Temp/10]);
			Delay(200);							  
			SMG_DisplayBit(6,SMG_Duan[Temp%10]);
			Delay(200);
			SMG_DisplayBit(7,SMG_Duan[12]);		  // C
			Delay(200);
		}	
		SMG_Close(0xff);
		Delay(200);
}

//-------------------------------------�¶ȶ�ȡ--------------------------
void Read_Temperature(void)
{
 	unsigned char LSB,MSB;	//LSB d�Ͱ�λ  MSB �߰�λ
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
	Delay(1000);

	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);

	LSB = Read_DS18B20();
	MSB = Read_DS18B20();
	init_ds18b20();
	Temp = (MSB  << 8) | LSB;
	Temp = Temp >> 4; //�Ƴ�С������
}

//-----------------------------------��ʱ����ʼ��-----------------------
void Init_Timer0(void)
{
 	TMOD = 0x01;
	TH0  = (65535-100)/256;
	TL0  = (65535-100)%256;
	ET0  = 1;
	TR0  = 1;
	EA   = 1;
}

//-----------------------------------------��������-----------------------
void Key_Scans(void)
{
 	if(S4 == 0)	  //����ģʽ�л� 1-˯�߷� 2-��Ȼ�� 3-����
	{
	 	Delay(20);
		if(S4 == 0)
		{
			
		 	 while(S4 == 0)
			 {
					SMG_DisplayTemp_Data();
			 }
			 work_mode++;
			 if(work_mode > 3)
			 {
					work_mode = 1;
			 }
			 pwm_duty = pwm_num[work_mode-1]	;
		}
	}
	//S5 ��ʱ����	 0 60s 120s
	if(S5 == 0)
	{
	 	Delay(20);
		if(S5 == 0)
		{
		 		while(S5 == 0)
				{
				 	 SMG_DisplayTemp_Data();
				}
				num++;
				pwm_start = 1;
				if(num == 3)
				{
				 	num = 1;
				}
			time_value = work_time[num];
		}
	}

		//S6--��S9 ֹͣ���� ����ʱ��PWM ֹͣ���
	if(S6 == 0)
	{
	 	Delay(20);
		if(S6 == 0)
		{
		 	while(S6 == 0)
			{
				 SMG_DisplayTemp_Data();
			}
			pwm_start = 0;
			time_value = 0;
		}

	}
		//S7 -->s8 ���Ұ��� ������ʾ�¶� �ٴΰ��·��ع���ģʽ

	if(S7 == 0)
	{
	 	Delay(20);
		if(S7 == 0)
		{
		 	while(S7 == 0)
			{
				SMG_DisplayTemp_Data();
			}
			if(work_or_time == 1)
			{
			 	work_or_time = 0;
			}
			else
			{
			 	work_or_time = 1;
			}
		}
	}
}
//-----------------------------������-------------------------------------
void main(void)
{
	InitSystem();
	Init_Timer0();
 	while(1)
	{
		
		SMG_DisplayTemp_Data();
		Read_Temperature();
		Key_Scans();
		if(pwm_start == 0)
		{
		 	XBYTE[0x8000] = 0xff;
		}
	}
}

//-------------------------------��ʱ��������---------------------------
void SeverTime() interrupt 1
{
	TH0=(65535-100)/256;
	TL0=(65535-100)%256;
	if(pwm_start==1)
	{
		pwm++;
  	count++;
		if(pwm==pwm_duty)
		{
			XBYTE[0x8000]=0xff;
		}
		else if(pwm==100)
		{
			pwm=0;
			XBYTE[0x8000]=led_value[work_mode-1];
		}
		if(count==10000)		 //1s
		{
			time_value--;	
			if(time_value<=0)
			{
				pwm_start=0;
				time_value=0;
			}				
			count=0;
		}
	}
	
}