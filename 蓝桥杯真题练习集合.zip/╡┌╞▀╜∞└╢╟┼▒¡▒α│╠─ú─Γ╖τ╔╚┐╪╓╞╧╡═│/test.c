#include<reg52.h>
#include<absacc.h>
#include"onewire.h"
sbit S7=P3^0;
sbit S6=P3^1;
sbit S5=P3^2;
sbit S4=P3^3;
unsigned char T_dat;
unsigned char pwm=0;
unsigned char pwm_duty=20;
unsigned char pwm_num[]={20,30,70};
unsigned char code LED[]={0xfe,0xfd,0xfb};
unsigned char num=0;
unsigned int count =0;
unsigned char code dtime[]={0,60,120};
unsigned char mode=1;
unsigned char a=1;
signed char time=0;
unsigned char code LedChar[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
unsigned char start=1;
void Delay(unsigned int t)
{
	while(t--);
}
void Display_Bit(unsigned char pos,unsigned char value)
{
	XBYTE[0xc000]=0x01<<pos;
	XBYTE[0xe000]=value;
}
void Display_All()
{
	XBYTE[0xe000]=0xff;
	XBYTE[0xc000]=0xff;
}
void Display_SMG()
{
	Display_Bit(0,0xbf);
	Delay(200);
	Display_Bit(2,0xbf);
	Delay(200);
	Display_Bit(3,0xff);
	Delay(200);
	if(a==1)
	{
		Display_Bit(1,LedChar[mode]);
  	Delay(200);
		Display_Bit(4,LedChar[0]);
		Delay(200);
		Display_Bit(5,LedChar[time/100]);
		Delay(200);
		Display_Bit(6,LedChar[(time%100)/10]);
		Delay(200);
		Display_Bit(7,LedChar[time%10]);
		Delay(200);
	}
	else
	{
		Display_Bit(1,LedChar[4]);
  	Delay(200);
		Display_Bit(4,0xff);
		Delay(200);
		Display_Bit(5,LedChar[T_dat/10]);
		Delay(200);
		Display_Bit(6,LedChar[T_dat%10]);
		Delay(200);
		Display_Bit(7,~0x39);
		Delay(200);
	}
	Display_All();
}
void InitTime0()
{
	TMOD=0x01;
	TH0=(65535-100)/256;
	TL0=(65535-100)%256;
	TR0=1;
	ET0=1;
	EA=1;
}
void SeverTime() interrupt 1
{
	TH0=(65535-100)/256;
	TL0=(65535-100)%256;
	if(start==1)
	{
		pwm++;
  	count++;
		if(pwm==pwm_duty)
		{
			XBYTE[0x8000]=0xff;
		}
		else if(pwm==100)
		{
			pwm=0;
			XBYTE[0x8000]=LED[mode-1];
		}
		if(count==10000)
		{
			time--;	
			if(time<=0)
			{
				start=0;
				time=0;
			}				
			count=0;
		}
	}
	
}
void Read_tem()
{
	unsigned char LSB,MSB ;
	init_ds18b20();			
	Write_DS18B20(0xCC);			
	Write_DS18B20(0x44);
	Delay(500);
	init_ds18b20();	
	Write_DS18B20(0xCC);		
	Write_DS18B20(0xBE);			
	LSB = Read_DS18B20();		
	MSB = Read_DS18B20();			
	init_ds18b20();			
	T_dat = 0x0000;
	T_dat = MSB;
	T_dat <<= 8;
	T_dat = T_dat | LSB;
	T_dat >>= 4;
		
}
void Scan_Key()
{
	if(S4==0)
	{
		Delay(100);
		while(S4==0)
		{
			Display_SMG();
		}
		mode++;
		if(mode>3) mode=1;
		pwm_duty=pwm_num[mode-1];
	}
	if(S5==0)
	{
		Delay(100);
		while(S5==0);
			num++;
			start=1;
			if(num==3) num=0;
			time=dtime[num];
	}
	if(S6==0)
	{
		Delay(100);
		if(S6==0)
		{
			time=0;
			start=0;
		}
	}
	if(S7==0)
	{
		Delay(100);
		while(S7==0);
			if(a==1) a=0;
			else a=1;
	}
}
void main()
{
	XBYTE[0x8000]=0xff;
	XBYTE[0xa000]=0x00;
	InitTime0();
	while(1)
	{
		Display_SMG();
		Read_tem();
		Scan_Key();
		if(start==0) XBYTE[0x8000]=0xff;
	}
	
}