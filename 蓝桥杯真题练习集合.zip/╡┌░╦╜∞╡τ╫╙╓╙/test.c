 #include "reg52.h"
 #include "onewire.h"
 #include "absacc.h"


/*=================================================================
Date:2022-1-14
Author:С��ͬѧ
Version:1.1	IO��ʽ
==================================================================*/

sbit S7 = P3^0;
sbit S6 = P3^1;
sbit S5 = P3^2;
sbit S4 = P3^3;
sbit Led1 = P0^0;

unsigned char T_Hour = 23,T_Min= 59,T_Sec = 50;
unsigned char Temperature = 0;//�¶ȴ洢
unsigned char time_set = 0,clock_set = 0;//ʱ�����ú�����ʱ�ӱ�־
unsigned char t_count0 = 0,t_flag = 0,t_count1,c_count = 0;//��ʱ����˸��־
unsigned char code smg_duan[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};
//------------------------------����ʱ----------------------------
void Delay(unsigned int t)
{
 	while(t--);
}
//--------------------------74CHC138��ʼ��-------------------------
void  Init_74HC138(unsigned char n)
{
 	switch(n)
	{
	 	case 0:P2 = (P2 & 0x1f) | 0x00;break;
		case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
	}
}
//-------------------------ϵͳ��ʼ��-----------------------------
void InitSyetem(void)
{
 	Init_74HC138(4);
	P0 = 0xff; //�ر�LED
	Init_74HC138(5);
	P0 = 0x00;//�رռ̵����ͷ�����
}
//-------------------------����ܰ�λ��ʾ-------------------------
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	Init_74HC138(6);
	P0 = (0x01 << pos);
	Init_74HC138(7);
	P0 = dat;
}

void SMG_Close(void)
{
 	Init_74HC138(6);
	P0 = 0xff;
	Init_74HC138(7);
	P0 = 0xff;
}
//-----------------------�������ʾ------------------------------
void SMG_Display(void)
{
	SMG_DisplayBit(0,smg_duan[T_Hour/10]);
  Delay(200);
	SMG_DisplayBit(1,smg_duan[T_Hour%10]);
	Delay(200);
	SMG_DisplayBit(2,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(3,smg_duan[T_Min/10]);
	Delay(200);
	SMG_DisplayBit(4,smg_duan[T_Min%10]);
	Delay(200);
	SMG_DisplayBit(5,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(6,smg_duan[T_Sec/10]);
	Delay(200);
	SMG_DisplayBit(7,smg_duan[T_Sec%10]);
	Delay(200);	
	SMG_Close();
}

void SMG_Hour_Flash(void)
{
	SMG_DisplayBit(2,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(3,smg_duan[T_Min/10]);
	Delay(200);
	SMG_DisplayBit(4,smg_duan[T_Min%10]);
	Delay(200);
	SMG_DisplayBit(5,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(6,smg_duan[T_Sec/10]);
	Delay(200);
	SMG_DisplayBit(7,smg_duan[T_Sec%10]);
	Delay(200);
	if(t_flag == 0)
	{
	 	 	SMG_DisplayBit(0,smg_duan[T_Hour/10]);
			Delay(200);
			SMG_DisplayBit(1,smg_duan[T_Hour%10]);
			Delay(200);
	}
	else
	{
	 		SMG_DisplayBit(0,smg_duan[11]);
			Delay(200);
			SMG_DisplayBit(1,smg_duan[11]);
			Delay(200);
	}
	SMG_Close();
}

void SMG_Min_Flash(void)
{
	SMG_DisplayBit(0,smg_duan[T_Hour/10]);
	Delay(200);
	SMG_DisplayBit(1,smg_duan[T_Hour%10]);
	Delay(200);
	SMG_DisplayBit(2,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(5,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(6,smg_duan[T_Sec/10]);
	Delay(200);
	SMG_DisplayBit(7,smg_duan[T_Sec%10]);
	Delay(200);
	if(t_flag == 0)
	{
		 	SMG_DisplayBit(3,smg_duan[T_Min/10]);
			Delay(200);
			SMG_DisplayBit(4,smg_duan[T_Min%10]);
			Delay(200); 	
	}
	else
	{
	 		SMG_DisplayBit(3,smg_duan[11]);
			Delay(200);
			SMG_DisplayBit(4,smg_duan[11]);
			Delay(200);
	}
	SMG_Close();
}

void SMG_Sec_Flash(void)
{
	SMG_DisplayBit(0,smg_duan[T_Hour/10]);
	Delay(200);
	SMG_DisplayBit(1,smg_duan[T_Hour%10]);
	Delay(200);
	SMG_DisplayBit(2,smg_duan[10]);
	Delay(200);
	SMG_DisplayBit(3,smg_duan[T_Min/10]);
	Delay(200);
	SMG_DisplayBit(4,smg_duan[T_Min%10]);
	Delay(200); 
	SMG_DisplayBit(5,smg_duan[10]);
	Delay(200);
	
	if(t_flag == 0)
	{
		  SMG_DisplayBit(6,smg_duan[T_Sec/10]);
			Delay(200);
			SMG_DisplayBit(7,smg_duan[T_Sec%10]);
			Delay(200);	
	}
	else
	{
	 		SMG_DisplayBit(6,smg_duan[11]);
			Delay(200);
			SMG_DisplayBit(7,smg_duan[11]);
			Delay(200);
	}
	SMG_Close();
}
//---------------------------------�¶ȶ�ȡ------------------------
void Read_Temperature(void)
{
 	unsigned char LSB = 0,MSB = 0;
	init_ds18b20();
	Write_DS18B20(0xcc);//����Rom
	Write_DS18B20(0x44);//��ʼת��

	Delay(500);
	init_ds18b20();
	Write_DS18B20(0xcc);//����Rom
	Write_DS18B20(0xbe);//��ȡ�¶ȵ��ݴ���

	LSB = Read_DS18B20();//��ȡ��0�ֽ�
	MSB = Read_DS18B20();//��ȡ��1�ֽ�

	Temperature = (MSB << 8)| LSB;
	Temperature = Temperature >> 4;//��������
	
	/*
		С������
		if((Temperature & 0x1f)	!= 0x0000) //����λΪ���� ȫ��Ϊ+
		{
		  Temperature = Temperature >> 4;
			Temperature = Temperature * 10;
			Temperature = Temperature + (LSB & 0x0f) *0.625;
		}	
	*/ 
}
//-------------------------------�¶���ʾ---------------------------
void Temperature_Display(void)
{
 	SMG_DisplayBit(0,smg_duan[11]);
  Delay(200);
	SMG_DisplayBit(1,smg_duan[11]);
	Delay(200);
	SMG_DisplayBit(2,smg_duan[11]);
	Delay(200);
	SMG_DisplayBit(3,smg_duan[11]);
	Delay(200);
	SMG_DisplayBit(4,smg_duan[11]);
	Delay(200);
	SMG_DisplayBit(5,smg_duan[Temperature/10]);
	Delay(200);
	SMG_DisplayBit(6,smg_duan[Temperature%10]);
	Delay(200);
	SMG_DisplayBit(7,0xC6);	 // C
	Delay(200);	
	SMG_Close();
}

//----------------------------------��������------------------------
void KeyScans(void)
{
 	if(S7 == 0)
	{
	 	Delay(20);
		if(S7 == 0)
		{			
		 	while(S7 == 0);
			time_set++;
			ET0 = 0,TR0 = 0;
			if(time_set == 1)
			{
					//ʱ����
					SMG_Hour_Flash();
			}
			else if(time_set == 2)
			{
				 //������
				 SMG_Min_Flash();
				
			}
			else if(time_set > 3)
			{
				//��
				SMG_Sec_Flash();
			 	time_set = 0;	
				ET0 = 1,TR0 = 1;			
			}
		}
}	

	if(S5 == 0)
	{
	 	Delay(20);
		if(S5 == 0)
		{
			while(S5 == 0);
			if(time_set == 1) //Сʱ���м�
			{
			 	T_Hour++;
				if(T_Hour >= 24) //�߽紦��
				{
				 	T_Hour = 0;
				}
			}
			else if(time_set == 2) //���ӽ��м�
			{
				 T_Min++;
				 if(T_Min >= 60) //�߽紦��
				 {
						T_Min = 0;
				 }
			}
			else if(time_set == 3)//����м�
			{
			 		T_Sec++;
					if(T_Sec >= 60) //�߽紦��
					{
					 	T_Sec = 0;
					}
			}
		}
}
		if(S4 == 0)
		{
		 	Delay(20);
			if(S4 == 0)
			{
				while(S4 == 0);
				if(time_set == 1)//ʱ���м�
				{
					T_Hour--;
					if(T_Hour == 0)//�߽紦��
					{
					 	T_Hour = 24;
					}
				}
				else if(time_set == 2) //���Ӽ�
				{
				 	T_Min--;
					if(T_Min == 0) //�߽紦��
					{
					 	T_Min = 60;
					}
				}
				else if(time_set == 3) //����м�
				{
					T_Sec--;
					if(T_Sec == 0)//�߽紦��
					{
					 	T_Sec = 60;
					}
				}
			}
		}
}
//-------------------------------------��ʱ����ʼ��-------------------
void Init_Timer0(void)
{
 	TMOD = 0x11; //��ʱ��0 ��ʱ��1 	��ʽһ16 
	TH0 = (65535-50000)/256;//50ms
	TL0 = (65535-50000)%256;

	TH1 = (65535-50000)/256;//50ms
	TL1 = (65535-50000)%256;
	ET1 = 1;
	TR1 = 1;
	ET0 = 1;
	TR0 = 1;
	EA  = 1;
}
//-----------------------------������-------------------------------
void main(void)
{
	InitSyetem();
	Init_Timer0();
	while(1)
	{
		//��ȡ�¶�
		 Read_Temperature();
		if((time_set == 0) && (clock_set == 0))
		{
			if(S4 == 0)
			{
				Delay(20);
				if(S4 == 0)
				{
				 	while(S4 == 0)
					{
						 Delay(200);
						//��ʾ�¶�
						Temperature_Display();
					}
				}
			 	
			}		
			SMG_Display(); //ʱ��ʵʱ��ʾ	
		}				         
	 	KeyScans();	

			switch(time_set)
			{
			 	case 1:SMG_Hour_Flash();break;
				case 2:SMG_Min_Flash();break;
				case 3:SMG_Sec_Flash();break;
			}		
	}	 
}
//-----------------------------��ʱ���жϷ���-------------------------
void Server_Timero() interrupt 1
{
 	TH0 = (65535-50000)/256;
	TL0 = (65535-50000)%256;
	t_count0++;
	if(t_count0 == 20) // 1s ʱ�������־
	{
	 	t_count0 = 0;
		if(T_Sec++ == 60) 
		{
		 	T_Sec = 0;
			T_Min++;
			if(T_Min == 60)
			{
			 	T_Min = 0;
				T_Hour++;
				if(T_Hour == 24)
				{
				 	T_Hour = 0;
				}
			}			   
		}
	}
}

void Server_Timer1() interrupt 3
{
 	TH1 = (65535-50000)/256;//50ms
	TL1 = (65535-50000)%256;
	t_count1++;
	if(t_count1 == 20) //1s
	{
	 	t_count1 = 0;
		t_flag = ~t_flag;
	}
}