#include "reg52.h"

//�ĸ�������������
sbit S7 = P3^0;
sbit S6 = P3^1;
sbit S5 = P3^2;
sbit S4 = P3^3;

//LED����
sbit L1 = P0^1;
sbit L2 = P0^2;
sbit L3 = P0^3;
sbit L4 = P0^4;
sbit L5 = P0^5;
sbit L6 = P0^6;
sbit L7 = P0^7;

//-------------------------------������ʱ����--------------------------
void delay(unsigned char t)
{
	while(t--);
}
//----------------------------------------------------------------------


//------------------------------74HC138��ʼ��---------------------------
void Init_74HC138(unsigned char n)
{
 	switch(n)
	{
	 	case 4:P2 = P2 | 0x1f; P2 = 0x80; break;		//Y4
		case 5:P2 = P2 | 0x1f; P2 = 0xa0; break;		//Y5
		case 6:P2 = P2 | 0x1f; P2 = 0xc0; break;		//Y6
		case 7:P2 = P2 | 0x1f; P2 = 0xe0; break;		//Y7
	}
}
//---------------------------------------------------------------------


//---------------------------�رռ̵����ͷ�����------------------------
void InitSystem(void)
{
 	Init_74HC138(5);
	P0 = 0x00;
}
//---------------------------------------------------------------------


//----------------------------��������ɨ�躯��-------------------------
unsigned char status = 0;//״̬��־λ
void KeyScan_Single(void)
{
 	if(S7 == 0)
	{
		delay(20);
		if(S7 == 0)
		{
			if(status  == 0)
			{
				 L1 = 0;
				 status = 1;
			}
			else if(status == 1)
			{
			 		L1 = 1;
					status = 0;
			}
			while(S7 ==0);			
		}
	}

		if(S6 == 0)
	{
		delay(20);
		if(S6 == 0)
		{
			if(status == 0)
			{
				L2 = 0;
				status = 2;
			}
			else if(status == 2)
			{
			 	L2 = 1;
				status = 0;
			}
			while(S6 == 0);
		}
	}

		if(S5 == 0)
	{
		delay(20);
		if(S5 == 0)
		{
			if(status == 1)
			{
				L3 = 0;
				while(S5 == 0);
				L3 = 1;
			}
			else if(status == 2)
			{
			 	L5 = 0;
				while(S5 == 0);
				L5 = 1;
			}
		}
	}

		if(S4 == 0)
	{
		delay(20);
		if(S4 == 0)
		{
			if(status == 1)
			{
					L4 = 0;
					while(S4 == 0);
					L4 = 1;
			}
			else if(status == 2)
			{
			 		L6 = 0;
					while(S4 == 0);
					L6 = 1;
			}
		
		}
	}
}
//---------------------------------------------------------------------



//-----------------------------------������-----------------------------
void main(void)
{
	InitSystem();
	Init_74HC138(4);
	P0 = 0xff;
 	while(1)
	{		
		KeyScan_Single();

	}
}