#include "reg52.h"
#include "absacc.h"


sbit S4 = P3^3;
sbit S7 = P3^0;

unsigned char pwm = 0; //������
unsigned char pwm_duty = 0; //ռ�ձ�
unsigned char times = 0; //0.5s�仯
unsigned char key_value = 0;//��ֵ��¼
unsigned char led_start = 0; //led pwm
unsigned char status = 0;
unsigned char status_go = 0;


unsigned char code SMG_duanma[18]=
		{0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,
		 0x88,0x80,0xc6,0xc0,0x86,0x8e,0xbf,0x7f};

//-----------------------------------����ʱ------------------------
void Delay(unsigned int t)
{
 	while(t--);
}


//---------------------------74hc138---------------------------------
void Init_74HC138(unsigned char n)
{
 	switch(n)
	{
	 	case 4:P2 = (P2 | 0x1f) & 0x80;break;
		case 5:P2 = (P2 | 0x1f) & 0xa0;break;
		case 6:P2 = (P2 | 0x1f) & 0xc0;break;
		case 7:P2 = (P2 | 0x1f) & 0xe0;break;
	}

}


//-------------------------------ϵͳ��ʼ��----------------------------
void Init_System(void)
{
 	Init_74HC138(4);
	P0 = 0xff;   //�ر�����Led
	Init_74HC138(5);
	P0 = 0x00;   //�رռ̵����ͷ�����
}


//----------------------------------�������غ���-----------------------
//��λ��ʾ
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	Init_74HC138(6);
	P0 = (0x01 << pos);
	Init_74HC138(7);
	P0 = dat;
}

//�ر����������
void SMG_Close(unsigned char dat)
{
 	Init_74HC138(6);
	P0 = 0xff;
	Init_74HC138(7);
	P0 = dat;
}


//�����������ʾ
void SMG_Display_Data(unsigned char status,unsigned char duty)
{
 	 SMG_DisplayBit(0,SMG_duanma[status]);
	 Delay(200);
	 SMG_DisplayBit(1,0xff);
	 Delay(200);
	 SMG_DisplayBit(2,0xff);
	 Delay(200);
	 SMG_DisplayBit(3,0xff);
	 Delay(200);
	 SMG_DisplayBit(4,0xff);
	 Delay(200);
	 SMG_DisplayBit(5,0xff);
	 Delay(200);
	 SMG_DisplayBit(6,SMG_duanma[duty/10]);
	 Delay(200);
	 SMG_DisplayBit(7,SMG_duanma[duty%10]);
	 Delay(200);
	 
	 SMG_DisplayBit(0,0xff);
	 Delay(200);
	 SMG_DisplayBit(6,0xff);
	 Delay(200);
	 SMG_DisplayBit(7,0xff);
	 Delay(200);

}


 

//------------------------------------��ʱ����ʼ��-------------------------
void Init_Timer0(void)
{
	TMOD = 0x01;
	TH0 = (65535-1000)/256;
	TL0 = (65535-1000)%256;
	ET0 = 1;
	TR0 = 1;
	EA  = 1;
}



//------------------------------Led����---------------------------
void Led_Control(void)
{
 	if(times == 5)
	{
	 	times = 0;
		if(led_start == 0)
		{
		 	//����ռ�ձ�
			pwm_duty += 1;
			if(pwm_duty == 11) //���Ϊ1������10
			{
			 	pwm_duty = 10;
				led_start = 1; //״̬��ת
			}
		}
		else if(led_start == 1)
		{
		 	//��Сռ�ձ�
			pwm_duty -= 1;
			if(pwm_duty == 255)	 //������Сֵ��
			{
			 	pwm_duty = 0;
				led_start = 0; //״̬�ڷ�ת
				if(status_go == 1)	//������
				{
				 	status ++;
					if(status == 8)
					{
					 	status = 0;
					}
				}
				else if(status_go == 2)//���ҵ���
				{
					 status--;
					 if(status == 255)
					 {
							status = 7;
					 }
				}
			}
		}
	}
}
//-----------------------------������������-------------------------
void Key_Tackle(void)
{
 	 if(S4 == 0)
	 {
			Delay(20);
			if(S4 == 0)
			{
			 	while(S4 == 0)
				{
				 	key_value = 1;
				}
					key_value = 0;
					status_go++;
					if(status_go == 3)
					{
					 		status_go = 1;
					}
			}
	 }

	 if(S7 == 0)
	 {
			Delay(20);
			if(S7 == 0)
			{
			 	while(S7 == 0)
				{
				 	key_value = 1;
					SMG_Display_Data(status+1,pwm_duty*10);
				}
				key_value = 0;				

			}
	 }
}
//-----------------------------------������-------------------------------
void main(void)
{
	Init_System();
	Init_Timer0();
 	while(1)
	{
		 Led_Control();
		 Key_Tackle();
	}

}
//---------------------------------�жϷ�����------------------------------
void Server_Timer0() interrupt 1
{
	TH0 = (65535-1000)/256;
	TL0 = (65535-1000)%256;
	if(status_go == 0)
	{
	 	//Ĭ��Led״̬L4 L5������Ϩ��
		Init_74HC138(4);
		P0 = 0xe7;  //1110 0111 
	}
	pwm++;
	if(pwm < pwm_duty)	 //С��Ϊ�͵�ƽ��
	{
			Init_74HC138(4);
			P0 = ~(0x01 << status);	  //0000 0001 -��1111 1110
	}
	else if(pwm <= 10)	  //����Ϊ10
	{
		Init_74HC138(4);
		P0 = 0xff;  //Ϩ��
	}
	else		 //pwm > 10 --->���¿�ʼ
	{
			pwm = 0;
			Init_74HC138(4);
			P0 = ~(0x01 << status);
			if(key_value == 0)
			{
			 	 times++;
			}
	}
}

