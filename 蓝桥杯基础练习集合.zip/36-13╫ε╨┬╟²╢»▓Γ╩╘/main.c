#include "reg52.h"
#include "onewire.h"
#include "iic.h"
#include "ds1302.h"


sbit S4 = P3^3;
unsigned char interface = 0;//����
unsigned int T_value = 0;//�¶�
float T_temp = 0;
unsigned int smg_volt= 0,adc_volt = 0;		//��ѹ
unsigned char code write_ds1302_addr[] = {0x80,0x82,0x84,0x86,0x88,0x8a,0x8c};
unsigned char code Read_ds1302_addr[]  = {0x81,0x83,0x85,0x87,0x89,0x8b,0x8d};
unsigned char Init_Timer[] = {0x50,0x59,0x16};//Ĭ��ʱ��16ʱ59��50��
unsigned char code smg_data[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0xbf};
unsigned char code smg_data_dot[10]={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};


//����ʱ
void delay(unsigned int t)
{
 	while(t--);
}

//��ʼ��������
void Init_74HC138(unsigned char channel)
{
 	switch(channel)
	{
	 	case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break;
	}
		P2 = (P2 & 0x1f) | 0x00;
}


//�������������
void  SMG_All(unsigned char dat)
{
 	P0 = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}



//��λ���������
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//�¶Ȼ�ȡ
/*
void Read_Temperature(void)
{
 	unsigned char LSB = 0,MSB = 0;
	unsigned int temp = 0;

	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
	delay(1000);

	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	LSB = Read_DS18B20();
	MSB = Read_DS18B20();
	init_ds18b20();
	temp = (MSB << 8) | LSB ;
	if((temp & 0xf800) == 0x0000)
	{
	 	T_temp = temp *0.0625; //��������ת������
	}
	T_value = T_temp * 100;//�������ʾ
}

*/
void Read_Temperature(void)
{
 	unsigned char LSB = 0,MSB = 0;
	unsigned int temp = 0;

	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
	delay(1000);

	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	LSB = Read_DS18B20();
	MSB = Read_DS18B20();
	init_ds18b20();
	temp = (MSB << 8) | LSB ;
	if((temp & 0xf800) == 0x0000)
	{
	 	T_temp = temp *0.0625; //��������ת������
	}
	T_value = T_temp * 10;//�������ʾ
}





//��ȡ��ѹ	
void Read_Voltage(void)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x03);
	IIC_WaitAck();
	IIC_Stop();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	adc_volt = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop(); 
	//����ת������
	smg_volt = adc_volt *(5.0/255)*100;
}


//д���ʼ��ʱ��
void Write_Timer(void)
{
 	unsigned char i = 0;
	Write_Ds1302_Byte(0x8e,0x00); //�ر�д����
	for(i = 0; i<7;i++)
	{
	 	Write_Ds1302_Byte(write_ds1302_addr[i],Init_Timer[i]);
	}
	Write_Ds1302_Byte(0x8e,0x80); //��д����
}


//��ȡʱ��
void Read_Timer(void)
{
 	unsigned char i = 0;
	for(i =0;i< 7;i++)
	{
		Init_Timer[i] = Read_Ds1302_Byte(Read_ds1302_addr[i]);
	}
}



//1.�¶���ʾ
void SMG_Display_Temperature(void)
{
		//C -> 0110 0011 0xC6
	 SMG_DisplayBit(0,0xc6);
	 delay(200);
	 SMG_DisplayBit(1,0xff);
	 delay(200);
	 SMG_DisplayBit(2,0xff);
	 delay(200);
	 SMG_DisplayBit(3,0xff);
	 delay(200);
//	 SMG_DisplayBit(4,smg_data[T_value/1000]);
//	 delay(200);
	 SMG_DisplayBit(5,smg_data[T_value/100]);
	 delay(200);
	 SMG_DisplayBit(6,smg_data_dot[T_value/10%10]);
	 delay(200);
	 SMG_DisplayBit(7,smg_data[T_value%10]);
	 delay(200);
	 SMG_All(0xff);
	 delay(200);
}

//3.��ѹ��ʾ
void SMG_Display_V(void)
{
		//E -> 0110 0001	  0X86
	 SMG_DisplayBit(0,0x86);
	 delay(200);
	 SMG_DisplayBit(1,0xff);
	 delay(200);
	 SMG_DisplayBit(2,0xff);
	 delay(200);
	 SMG_DisplayBit(3,0xff);
	 delay(200);
	 SMG_DisplayBit(4,0xff);
	 delay(200);
	 SMG_DisplayBit(5,smg_data[smg_volt/100]);
	 delay(200);
	 SMG_DisplayBit(6,smg_data_dot[smg_volt/10%10]);
	 delay(200);
	 SMG_DisplayBit(7,smg_data[smg_volt%10]);
	 delay(200);
	 SMG_All(0xff);
	 delay(200);
}

void SMG_Display_Time(void)
{
		//C -> 0110 0011 0xC6
	 SMG_DisplayBit(0,smg_data[Init_Timer[2]/16]);
	 delay(200);
	 SMG_DisplayBit(1,smg_data[Init_Timer[2]%16]);
	 delay(200);
	 SMG_DisplayBit(2,0xbf);
	 delay(200);
	 SMG_DisplayBit(3,smg_data[Init_Timer[1]/16]);
	 delay(200);
	 SMG_DisplayBit(4,smg_data[Init_Timer[1]%16]);
	 delay(200);
	 SMG_DisplayBit(5,0xbf);
	 delay(200);
	 SMG_DisplayBit(6,smg_data[Init_Timer[0]/16]);
	 delay(200);
	 SMG_DisplayBit(7,smg_data[Init_Timer[0]%16]);
	 delay(200);
	 SMG_All(0xff);
	 delay(200);
}

void Key_Scans(void)
{
 	if(S4 == 0)
	{
	 	delay(20);
		if(S4 == 0)
		{
		 	while(S4 == 0)
			{
			 	if(interface == 0)
				{
				 	interface = 1;
					SMG_Display_Temperature();
				}
				else if(interface == 1)
				{
				 	interface = 2;
					SMG_Display_V();
				}
				else if(interface == 2)
				{
				 	interface = 0;
					SMG_Display_Time();
				}
			}
		}
	}
}
//ϵͳ��ʼ��
void Init_System(void)
{
 	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
	SMG_All(0xff);
}


void main(void)
{
	Init_System();
	Write_Timer();
 	while(1)
	{	
		Read_Temperature();
		SMG_Display_Temperature();
//		Read_Voltage();
//		Read_Timer();	
//		Key_Scans();
/*
		switch(interface)
		{
		 	case 0:SMG_Display_Temperature();break;
			case 1: SMG_Display_V();break;
			case 2:SMG_Display_Time();
		}
		*/		
	}
}
