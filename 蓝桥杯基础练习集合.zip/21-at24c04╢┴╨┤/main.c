#include "reg52.h"
#include "iic.h"


unsigned char dat1,dat2,dat3;
unsigned char code smg_data[] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8, 0x80,0x90};


//1.����ʱ
void delay(unsigned int t)
{
 	while(t--);
}

//2.����������
void Init_74HC138(unsigned char n)
{
 	switch(n)
	{
	 	case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break;
	}
	P2 = (P2 & 0x1f) | 0x00;
}

//3.����ܰ�λ����
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
	//������
	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//�ر����������
void SMG_Close(void)
{
 	P0 = 0xff;
	Init_74HC138(6);
	P0 = 0xff;
	Init_74HC138(7);
}

//4.ϵͳ��ʼ��
void Init_System(void)
{
	Init_74HC138(0);
 	P0 = 0x00;
	Init_74HC138(5);
	P0 = 0xff;
	Init_74HC138(4);
}

//5.�����������ʾ
void SMG_Display_Data(void)
{
 	SMG_DisplayBit(0,smg_data[dat1/10]);
	delay(200);
	SMG_DisplayBit(1,smg_data[dat1%10]);
	delay(200);
	SMG_DisplayBit(2,0xbf);
	delay(200);
	SMG_DisplayBit(3,smg_data[dat2/10]);
	delay(200);
	SMG_DisplayBit(4,smg_data[dat2%10]);
	delay(200);
	SMG_DisplayBit(5,0xbf);
	delay(200);
	SMG_DisplayBit(6,smg_data[dat3/10]);
	delay(200);
	SMG_DisplayBit(7,smg_data[dat3%10]);
	delay(200);
	SMG_Close();
	delay(200);
}


//6.at24c02����д
void AT24C02_Write(unsigned char addr,unsigned char dat)
{	
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	IIC_SendByte(dat);
	IIC_WaitAck();
	IIC_Stop();
}

//7.at24c02���ݶ�
unsigned char AT24C02_Read(unsigned char addr)
{
 	unsigned char temp = 0;
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();

	IIC_Start();
	IIC_SendByte(0xa1);
	IIC_WaitAck();
	temp = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	return temp;
}

//8.���ݴ���
void Read_Write_Data(void)
{
 	//�ȶ�ȡ����
	dat1 = 	AT24C02_Read(0x01);
	dat2 =  AT24C02_Read(0x03);
	dat3 = 	AT24C02_Read(0x05);


	dat1  = dat1 +1;
	dat2  = dat2 +2;
	dat3  = dat3 + 3 ;
	if( dat1 > 10)
	{
	 	dat1 = 0;
	}
	if(dat2  > 20)
	{
	 	dat2 = 0;
	}
	if(dat3  > 30)
	{
	 	dat3 = 0;
	}

	//������д��ȥ
	AT24C02_Write(0x01,dat1);
	delay(1000);
	AT24C02_Write(0x03,dat2);
	delay(1000);
	AT24C02_Write(0x05,dat3);
	delay(1000);

}
void main(void)
{
 	Init_System();
	Read_Write_Data();
	while(1)
	{
		 	
		 SMG_Display_Data();

	}
}