#include "reg52.h"


sbit LED1 = P0^0;
sbit LED2 = P0^1;
sbit LED8 = P0^7;
unsigned char led_stat = 0xff;
unsigned char value1 = 0,value2 = 0;
unsigned char code smg_data[] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8, 0x80,0x90};


void SMG_Display_Data(void);//1.����ʱ

void delay(unsigned int t)
{
 	while(t--);
}


void Delay_s(unsigned int t)
{
  while(t--)
  {
    SMG_Display_Data();                //����ʱ�ڼ䱣�������ˢ��
  }
}
//2.��������ʼ��
void Init_74HC138(unsigned char channel)
{
 	switch(channel)
	{
	 	case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break;
	}
		P2 = (P2 & 0x1f) | 0x00;
}

//3.����ܰ�λ����
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//4.�������������
void SMG_All(unsigned char dat)
{
 	P0 = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//5.ϵͳ��ʼ��
void Init_System(void)
{
 	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
	SMG_All(0xff);
}

//6.�����������ʾ
void SMG_Display_Data(void)
{
	SMG_DisplayBit(0,smg_data[value1]);
	delay(200);
	SMG_DisplayBit(1,0xff);
	delay(200);
	SMG_DisplayBit(2,0xff);
	delay(200);
	SMG_DisplayBit(3,0xff);
	delay(200);
	SMG_DisplayBit(4,0xff);
	delay(200);
	SMG_DisplayBit(5,0xff);
	delay(200);
	SMG_DisplayBit(6,smg_data[value2/10]);
	delay(200);
	SMG_DisplayBit(7,smg_data[value2%10]);
	delay(200);
	SMG_All(0xff);
	delay(200);	
}


//7.led����
void Led_Tackle(void)
{
 	led_stat &= ~0x80;  //led8����
	P0 = led_stat;
	Init_74HC138(4);
	Delay_s(200);

	led_stat |= 0x80;   //Ϩ��
	P0 = led_stat;
	Init_74HC138(4);
	Delay_s(200);

	value2++;
	if(value2 == 100)
	{
	 	value2 = 0;
	}

	//led1 ��led2 ��ͬʱ��ת
	if((led_stat & 0x03) == 0x03)
	{
	 	led_stat &= ~0x03;
	}
	else
	{
	 	led_stat |= 0x03;
	}
	P0 = led_stat;
	Init_74HC138(4);
	value1++;
	if(value1 > 9)
	{
	 	value1 = 0;
	} 
}

void main(void)
{
	Init_System();
	while(1)
	{
		Led_Tackle();
		SMG_Display_Data();
	
	 	
	}

}