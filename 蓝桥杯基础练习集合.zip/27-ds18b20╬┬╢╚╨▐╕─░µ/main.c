
#include "reg52.h"
#include "onewire.h"



 float Temp_Temperature = 0;
unsigned int Temperature = 0;
//-------��������ܵĶ�����������С���㣩--------
unsigned char code smg_data[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,};
//unsigned char code smg_data_dot[] = {0xc0-0x80,0xf9-0x80,0xa0-0x80,0xb0-0x80,0x99-0x80 ,
//																0x92-0x80,0x82-0x80,0xf8-0x80,0x80-0x80,0x90-0x80};

unsigned char code smg_data_dot[10]={0x40,0x79,
    0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};
//����ʱ
void delay(unsigned int t)
{
 	while(t--);
}

//����������
void Init_74HC138(unsigned char channel)
{
 	switch(channel)
	{
	 	case 4:P2 = (P2 & 0x1f) |0x80;break;
		case 5:P2 = (P2 & 0x1f) |0xa0;break;
		case 6:P2 = (P2 & 0x1f) |0xc0;break;
		case 7:P2 = (P2 & 0x1f) |0xe0;break;
		case 0:P2 = (P2 & 0x1f) |0x00;break;
	}
		P2 = (P2 & 0x1f) | 0x00;
}

//����ܰ�λ����
void SMG_DisplayBit(unsigned char pos ,unsigned char dat)
{
 	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//�������������
void SMG_All(unsigned char dat)
{
 	P0 = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//�����������ʾ
void SMG_Display_T(void)
{
 	if((Temperature / 100 )!= 0)
	{
		SMG_DisplayBit(5,smg_data[Temperature /100]);
  	delay(200);
	}
	
	SMG_DisplayBit(6,smg_data_dot[Temperature /10 %10]);
	delay(200);
	SMG_DisplayBit(7,smg_data[Temperature % 10]);
	delay(200);
	SMG_All(0xff);
	delay(200);
}


//�¶����ݶ�ȡ
void Read_Temperature(void)
{
 	unsigned char LSB = 0,MSB = 0;
	unsigned int temp = 0;			  //һ��Ҫע������ �����ķ�Χ
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
	SMG_Display_T();
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	LSB = Read_DS18B20();
	MSB = Read_DS18B20();
	init_ds18b20();
	temp = (MSB << 8)| LSB;
	if((temp & 0xf800) == 0x0000)
	{
	 	Temp_Temperature = temp * 0.0625;
	}
	Temperature = Temp_Temperature * 10;
	SMG_Display_T();
}



void Init_System(void)
{
 	Init_74HC138(0);
	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
	SMG_All(0xff);
}
void main(void)
{
 	Init_System();
	while(1)
	{
			Read_Temperature();
	}
}



H4 = 0;
H1 = H2 = H3 = 1;
L1 = L2 = L3 = L4 = 1;
if(L3 == 0)
{
	delay(20);
	if(L3 == 0)
	{
		while(L3 == 0);
	}
		
}