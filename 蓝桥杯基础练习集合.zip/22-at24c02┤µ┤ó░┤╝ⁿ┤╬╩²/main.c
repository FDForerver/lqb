#include "iic.h"
#include "reg52.h"

sbit S6 = P3^1;
sbit S5 = P3^2;
sbit S4 = P3^3;

unsigned char s4_value = 0,s5_value = 0,s6_value = 0;
unsigned char code smg_data[] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8, 0x80,0x90};
//1.����ʱ
void delay(unsigned int t)
{
 	while(t--);
}

//2.��������ʼ��
void Init_74HC138(unsigned char channel)
{
 	switch(channel)
	{
	 	case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break;
	}
	P2 = (P2 & 0x1f) | 0x00;
}

//3.����ܰ�λ����
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//4.�������������
void SMG_All(unsigned char dat)
{
 	P0 = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}
//5.ϵͳ��ʼ��
void Init_System(void)
{
 	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
	SMG_All(0xff);
}

//6.�������ʾ����
void SMG_Display_Data(void)
{
 	SMG_DisplayBit(0,smg_data[s4_value/10]);
	delay(200);
	SMG_DisplayBit(1,smg_data[s4_value%10]);
	delay(200);
	SMG_DisplayBit(2,0xbf);
	delay(200);
	SMG_DisplayBit(3,smg_data[s5_value/10]);
	delay(200);
	SMG_DisplayBit(4,smg_data[s5_value%10]);
	delay(200);
	SMG_DisplayBit(5,0xbf);
	delay(200);
	SMG_DisplayBit(6,smg_data[s6_value/10]);
	delay(200);
	SMG_DisplayBit(7,smg_data[s6_value%10]);
	delay(200);
	SMG_All(0xff);
	delay(200);

}

//7.at24c02д����
void AT24C02_Write(unsigned char addr,unsigned char dat)
{
 	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	IIC_SendByte(dat);
	IIC_WaitAck();
	IIC_Stop();
}

//8.at24c04������
unsigned char AT24C02_Read(unsigned char addr)
{
	unsigned char temp = 0;
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();

	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	temp = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	return temp;
}

//9.ϵͳ�ϵ���ȴ�24C04�洢����0x00��0x01��0x02��������ַ��Ԫ��ȡ����
void AT24C02_Data_Init(void)
{
 	s4_value = 	AT24C02_Read(0x00);
	delay(1000);
	s5_value =  AT24C02_Read(0x01);
	delay(1000);
	s6_value =  AT24C02_Read(0x02);
	delay(1000);

}

//10.��������
void Key_Scans(void)
{
 if(S4 == 0)
 {
		delay(20);
		if(S4 == 0)
		{
		 	while(S4 == 0);
			s4_value++;
			if(s4_value > 13)
			{
			 	s4_value = 0;
			}
			AT24C02_Write(0x00,s4_value);
		}
 }
 
 if(S5 == 0)
 {
		delay(20);
		if(S5 == 0)
		{
		 	while(S5 == 0);
			s5_value++;
			if(s5_value > 13)
			{
			 	s5_value = 0;
			}
			AT24C02_Write(0x01,s5_value);
		}
 	}
	
	if(S6 == 0)
 {
		delay(20);
		if(S6 == 0)
		{
		 	while(S6 == 0);
			s6_value++;
			if(s6_value > 13)
			{
			 	s6_value = 0;
			}
			AT24C02_Write(0x02,s6_value);
		}
 }				
}
void main(void)
{
	Init_System();
	AT24C02_Data_Init();
	while(1)
	{
	  SMG_Display_Data() ;

		Key_Scans();
	}
 	
}