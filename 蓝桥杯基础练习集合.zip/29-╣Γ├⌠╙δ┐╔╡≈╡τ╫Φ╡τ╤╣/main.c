#include "reg52.h"
#include "iic.h"

unsigned char rd1_value = 0,rd2_value = 0; //����������������
unsigned int smg_value1 = 0,smg_value2 =0; //�������ʾ
//����С�������
unsigned char code smg_data[18]={0xc0,0xf9,
    0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,
    0x88,0x80,0xc6,0xc0,0x86,0x8e,0xbf,0x7f};
//��С�������
unsigned char code smg_data_dot[10]={0x40,0x79,
    0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};

//����ʱ
void delay(unsigned int t)
{
 	while(t--);
}

//��������ʼ��
void Init_74HC138(unsigned char channel)
{
	switch(channel)
	{
	 	case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break;
	}
		P2 = (P2 & 0x1f) | 0x00;
}

//����ܰ�λ����
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//�������������
void SMG_All(unsigned char dat)
{
 	P0  = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}


//�����������ʾ
void SMG_Display_V(void)
{
	//������ѹ��ʾ
	 SMG_DisplayBit(0,smg_data_dot[smg_value1/100]);
	 delay(200);
	 SMG_DisplayBit(0,0xff);
	 delay(200);
	 SMG_DisplayBit(1,smg_data[smg_value1/10%10]);
	 delay(200);
	 SMG_DisplayBit(1,0xff);
	 delay(200);
	 SMG_DisplayBit(2,smg_data[smg_value1%10]);
	 delay(200);
	 SMG_DisplayBit(2,0xff);
	 delay(200);
	 SMG_DisplayBit(3,0xff);
	 delay(200);
	 SMG_DisplayBit(4,0xff);
	 delay(200);
	 //�����ѹ��ʾ
	 SMG_DisplayBit(5,smg_data_dot[smg_value2/100]);
	 delay(200);
	 SMG_DisplayBit(5,0xff);
	 SMG_DisplayBit(6,smg_data[smg_value2/10%10]);
	 delay(200);
	 SMG_DisplayBit(6,0xff);
	 delay(200);
	 SMG_DisplayBit(7,smg_data[smg_value2%10]);
	 delay(200);
	 SMG_DisplayBit(7,0xff);
	 delay(200);
	 SMG_All(0xff);
	 delay(200);
}

//��ȡ��������
void Read_AD1(void)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();	
	IIC_SendByte(0x01);
	IIC_WaitAck();
	IIC_Stop();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();	
	rd1_value = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	smg_value1 = rd1_value * (5.0/255) * 100;
}

//��ȡ��������
void Read_AD2(void)
{
	 
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();	
	IIC_SendByte(0x03);
	IIC_WaitAck();
	IIC_Stop();
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();	
	rd2_value = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	smg_value2 = rd2_value * (5.0/255) * 100;
}


//ϵͳ��ʼ��
void Init_System(void)
{
 	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
	SMG_All(0xff);
}


//������
void main(void)
{
 	Init_System();
	while(1)
	{
			Read_AD1();
			Read_AD2();
			SMG_Display_V();
	}
}