#include "reg52.h"
#include "iic.h"


unsigned char adc_temp =0;
float adc_value =0;
unsigned int adc_volt = 0;
unsigned char code smg_data[]={0xc0,0xf9,
    0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,
    0x88,0x80,0xc6,0xc0,0x86,0x8e,0xbf,0x7f};
//-------��������ܵĶ�����������С���㣩--------
//0.��9.
unsigned char code smg_data_dot[]={0x40,0x79,
    0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};


//����ʱ
void delay(unsigned int t)
{
 	while(t--);
}

//��������ʼ��
void Init_74HC138(unsigned char channel)
{
 	switch(channel)
	{
	 	case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break; 
	}
		P2 = (P2 & 0x1f) | 0x00;
}

//����ܰ�λ����
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//�������������
void SMG_All(unsigned char dat)
{
 	P0 = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//�����������ʾ
void SMG_Display_Data(void)
{
 	 SMG_DisplayBit(5,smg_data_dot[adc_volt/100]);
	 delay(200);
	 SMG_DisplayBit(5,0xff);
	 SMG_DisplayBit(6,smg_data[adc_volt/10%10]);
	 delay(200);
	 SMG_DisplayBit(6,0xff);
	 delay(200);
	 SMG_DisplayBit(7,smg_data[adc_volt%10]);
	 delay(200);
	 SMG_DisplayBit(7,0xff);
	 delay(200);
	 SMG_All(0xff);
	 delay(200);
}


//adc-set_dac
void Read_AD_SET_DA(void)
{
 	 IIC_Start();
	 IIC_SendByte(0x90);
	 IIC_WaitAck();
	 IIC_SendByte(0x43);
	 IIC_WaitAck();
	 IIC_SendByte(adc_temp);
	 IIC_WaitAck();
	 IIC_Stop();
	 SMG_Display_Data();
	 
	 IIC_Start();
	 IIC_SendByte(0x91);
	 IIC_WaitAck();
	 adc_temp = IIC_RecByte();
	 IIC_SendAck(1);
	 IIC_Stop();
	 adc_value = adc_temp * (5/255.0);
	 adc_volt = adc_value * 100;
	 SMG_Display_Data();
}


void Init_System(void)
{
	Init_74HC138(0);
	SMG_All(0xff);
	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
}
void main(void)
{
 	Init_System();
	while(1)
	{
		 Read_AD_SET_DA();
		 SMG_Display_Data();
	}

}