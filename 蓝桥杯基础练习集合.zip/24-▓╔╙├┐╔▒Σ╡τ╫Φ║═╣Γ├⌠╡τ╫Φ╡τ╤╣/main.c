#include "iic.h"
#include "reg52.h"

sbit S4 = P3^3;
unsigned char channel = 1;
unsigned int adc_value = 0,adc_volt = 0;
unsigned char code smg_data[] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8, 0x80,0x90};
unsigned char code smg_dot[] ={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};

//1.����ʱ
void delay(unsigned int t)
{
 	while(t--);
}

//2.��������ʼ��
void Init_74HC138(unsigned char channel)
{
 	switch(channel)
	{
	 	case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break;
	}
		P2 = (P2 & 0x1f) | 0x00;
}

//����ܰ�λ����
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//�������������
void SMG_All(unsigned char dat)
{
  P0 = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//ϵͳ��ʼ��
void Init_System(void)
{
 	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
	SMG_All(0xff);
}

//�����������ʾ
void SMG_Display_Data(void)
{
 	SMG_DisplayBit(0,0xbf);
	delay(200);
	SMG_DisplayBit(1,smg_data[channel]);
	delay(200);
	SMG_DisplayBit(2,0xbf);
	delay(200);
	SMG_DisplayBit(3,0xff);
	delay(200);
	SMG_DisplayBit(4,0xff);
	delay(200);
	SMG_DisplayBit(5,smg_dot[adc_volt/100]);
	delay(200);
	SMG_DisplayBit(6,smg_data[adc_volt/10%10]);
	delay(200);
	SMG_DisplayBit(7,smg_data[adc_volt%10]);
	delay(200);
	SMG_All(0xff);
	delay(200);
}

//PCF8591���ݶ�ȡ
void PCF8591_Read_Data(unsigned char channel)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	if(channel == 1)
	{
	 	IIC_SendByte(0x01);	
	}
	else if(channel == 3)
	{
	 	IIC_SendByte(0x03);	
	}
	IIC_WaitAck();
	IIC_Stop();

	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	adc_value = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	adc_volt = adc_value * (5.0/255)*100;		//����100��������ʾ	 	
}

//��������
void Key_Tackle(void)
{
 	if(S4 == 0)
	{
	 	delay(20);
		if(S4 == 0)
		{
		 	while(S4 == 0)
			{
			 	if(channel == 1)
				{
				 	channel = 3;
				}
				else if(channel == 3)
				{
				 	channel = 1;
				}
				PCF8591_Read_Data(channel);
			  SMG_Display_Data();
			}

		}
	}
}

//������
void main(void)
{
 	Init_System();
 	while(1)
	{
		
		Key_Tackle();
		PCF8591_Read_Data(channel);
		SMG_Display_Data();
	}
}