
//1.ADC 
//2.DAC
//3.温度
//4.AT24C02
//5.按键

//1.简单延时
void delay(unsigned int t)
{
	while(t--);
}

//2.初始化锁存器
void Init_74HC138(unsigned char channel)
{
	switch(channel)
	{
		case 4:P2 = (P2 & 0x1f) | 0x80;break;
		case 5:P2 = (P2 & 0x1f) | 0xa0;break;
		case 6:P2 = (P2 & 0x1f) | 0xc0;break;
		case 7:P2 = (P2 & 0x1f) | 0xe0;break;
		case 0:P2 = (P2 & 0x1f) | 0x00;break;
	}
		P2 = (P2 & 0x1f) | 0x00;
}

//3.安位操作数码管
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}

//4.操作所有数码管
void SMG_All(unsigned char dat)
{
	P0 = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}



//5.系统初始化
void Init_System(void)
{
	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
	SMG_All(0xff);	
}

//数码管显示数据
void SMG_Display_Data(void)
{
	SMG_DisplayBit(0,smg_data[0]);
	delay(200);
	SMG_DisplayBit(0,0xff);
	delay(200);
	SMG_DisplayBit(1,smg_data[1]);
	delay(200);
	SMG_DisplayBit(1,0xff);
	delay(200);
	SMG_DisplayBit(2,smg_data[2]);
	delay(200);
	SMG_DisplayBit(2,0xff);
	delay(200);
	SMG_DisplayBit(3,smg_data[3]);
	delay(200);
	SMG_DisplayBit(3,0xff);
	delay(200);
	SMG_DisplayBit(4,smg_data[4]);
	delay(200);
	SMG_DisplayBit(4,0xff);
	delay(200);
	SMG_DisplayBit(5,smg_data[5]);
	delay(200);
	SMG_DisplayBit(5,0xff);
	delay(200);
	SMG_DisplayBit(6,smg_data[6]);
	delay(200);
	SMG_DisplayBit(6,0xff);
	delay(200);
	SMG_DisplayBit(7,smg_data[7]);
	delay(200);
	SMG_DisplayBit(7,0xff);
	delay(200);
	SMG_All(0xff);
	delay(200);
}


/**************************模块练习************************/
//1.ADC  光敏电阻0x01   电位器 0x03 
//一般考ADC /DAC 写设备地址0x90  读设备地址0x91
//如果考eepram  缓存写设备地址0xa0,读设备地址0xa1
unsigned int adc_value = 0,smg_value = 0;
void Read_ADC(void)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x03);
	IIC_WaitAck();
	IIC_WaitAck();
	IIC_Stop();
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	adc_value = IIC_RecByte(); //模拟量
	IIC_SendAck(1);
	IIC_Stop();	 
	//5v ->255  
	smg_value = adc_value * (5.0/255*100); //2.35 -》235
}

//DAC
void Read_DAC(float dat)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x43);	
	IIC_WaitAck();
	IIC_SendByte(dat);
	IIC_WaitAck();
	IIC_Stop();
}

//读取温度
#include "onewire.h"
unsigned int T = 0;
void Read_Temperature(void)
{
	unsigned char LSB = 0,MSB = 0;
	unsigned int  temp = 0;
	
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
	delay(500);
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	LSB = Read_DS18B20();
	MSB = Read_DS18B20();
	
	T = (MSB << 8) | LSB;
	//题目要求不保留小数
	T = T >> 4;
	
	//如果题目要求保留两位小数
	/*
	if((T & 0xf800) = 0x0000)
	{
		T = T * 0.0625; //12.34
	}
	T = T *100;
	*/
}


//AT24C02 写入数据
void Write_AT24C02(unsigned char addr,unsigned char dat)
{
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	IIC_SendByte(dat);
	IIC_WaitAck();
	IIC_Stop();
}

//读取数据
unsigned int value = 0;

void Read_AT24C02(unsigned char addr)
{
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(addr);
	IIC_WaitAck();
	
	
	IIC_Start();
	IIC_SendByte(0xa1);
	IIC_WaitAck();
	value = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();I
}

//定时器
unsigned int  f_data = 0,f_count = 0,t_count = 0;
void Init_Timer(void)
{
	TMOD = 0x16; //定时器0计数 定时器1 定时
	TH0  = 0xff;
	TL0  = 0xff;
	TH1  = (65535-50000)/256; //50ms
	TL1  = (65535-50000)%256;
	ET0  = 1;
	ET1  = 1;
	TR0  = 1;
	TR1  = 1;
	EA   = 1;
}

//定时器0中断
void Server_Timer0() interrupt 1
{
	f_count++;
}

//定时器1 中断服务
void Server_Timer1() interrupt 3
{
	TH1  = (65535-50000)/256; //50ms
	TL1  = (65535-50000)%256;
	t_count++;
	if(t_count == 20)
	{
		t_count = 0;
		f_data = f_count;
		f_count = 0;
	}
}

// P4 ---> sfr P4 = 0xc0;

//按键处理
void Key_Scans(void)
{
	
	if(S4 == 0)
	{
		delay(20);
		if(S4 == 0)
		{
			while(S4 == 0)
			{
				//数码管显示函数放这里
			}
			
			//界面判断
			if(interface == 0)
			{
				interface = 1;
			}
			else if(interface == 1)
			{
				interface = 2;
			}
			else if(interface == 2)
			{
				interface = 0;
			}
			
			//下面写逻辑
		}
	}
	
	if(S5 == 0)
	{
		delay(20);
		if(S5 == 0)
		{
			while(S5 == 0)
			{
				//数码管显示函数放这里
			}
			//下面写逻辑
		}
	}
}

//led处理函数
sbit LED1 = P0^0;
....
void Led_Working(void)
{
	
	if(xxx)
	{
		//led1 open
	}else{
		close
	}
	//先传值 在选通锁存
	Init_74HC138(4);
}
//6.主函数
void main(void)
{
	Init_System();
	while(1)
	{
		Key_Scan();
		switch(interface)
		{
			/*显示函数*/
			case 0:SMG_Display_V();break;
			case 1:SMG_Display_T();break;
			case 2:SMG_Display_F();break;
		}
	}
}




