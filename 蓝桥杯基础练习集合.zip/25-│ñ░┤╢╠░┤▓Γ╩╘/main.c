#include "reg52.h"


sbit S7 = P3^0;
sbit S6 = P3^1;
sbit S5 = P3^2;
sbit S4 = P3^3;

unsigned char s_flag = 0;

unsigned char count = 0;
unsigned char s_mode = 0;

unsigned char code smg_data[] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8, 0x80,0x90};
void SMG_Display_Data(void);

//1.����ʱ
void delay(unsigned int t)
{
	while(t--)
	{
	 	SMG_Display_Data();
	}
}

void delay_smg(unsigned int t)
{
 	while(t--);
}

//����������
void Init_74HC138(unsigned char channel)
{
 	switch(channel)
	{
	 	case 4:P2 = (P2 & 0x1f)| 0x80;break;
		case 5:P2 = (P2 & 0x1f)| 0xa0;break;
		case 6:P2 = (P2 & 0x1f)| 0xc0;break;
		case 7:P2 = (P2 & 0x1f)| 0xe0;break;
		case 0:P2 = (P2 & 0x1f)| 0x00;break; 
	}
		P2 = (P2 & 0x1f) | 0x00;
}

//�������������
void SMG_All(unsigned char dat)
{
 	P0 = 0xff;
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}


//��λ���������
void SMG_DisplayBit(unsigned char pos,unsigned char dat)
{
 	P0 = (0x01 << pos);
	Init_74HC138(6);
	P0 = dat;
	Init_74HC138(7);
}
//�������ʾ����
void SMG_Display_Data(void)
{
	SMG_DisplayBit(0,0xbf);
	delay_smg(200);
	SMG_DisplayBit(1,smg_data[s_flag]);
	delay_smg(200);
	SMG_DisplayBit(2,0xbf);
	delay_smg(200);
	SMG_DisplayBit(3,0xff);
	delay_smg(200);
	SMG_DisplayBit(4,0xff);
	delay_smg(200);
	SMG_DisplayBit(5,smg_data[count/100]);
	delay_smg(200);
	SMG_DisplayBit(6,smg_data[count/10%10]);
	delay_smg(200);
	SMG_DisplayBit(7,smg_data[count%10]);
	delay_smg(200);
	SMG_All(0xff);
	delay_smg(200);

}
//2.����ɨ��
void  Key_Scans(void)
{
	if(S4 == 0)
	{
	 	delay_smg(20);
		if(S4 == 0)
		{
			count = 0;
			s_flag = 0;
			while(S4 == 0)
			{
				 SMG_Display_Data();
			}
			if(s_flag == 1) //����ʱ�䵽
			{
				if(s_mode == 0)
				{
					s_mode = 1;
					P0 = 0xfe;
					Init_74HC138(4);
				}
				else if(s_mode == 1)
				{
				 	s_mode = 0;
					P0 = 0xff;
					Init_74HC138(4);
				}
			}else  //����ʱ��δ�� ִ�ж̰�����
			{
				 P0 = 0xfd;
					Init_74HC138(4);
			}
		}
	}
}


//3.��ʱ����ʼ��
void Init_Timer(void)
{
 	TMOD = 0x01;
	TH0  =(65535-10000)/256; //10us
	TL0	 =(65535-10000)%256;
	ET0  = 1;
	TR0  = 1;
	EA   = 1;
}


//ϵͳ��ʼ��
void Init_System(void)
{
 	P0 = 0xff;
	Init_74HC138(4);
	P0 = 0x00;
	Init_74HC138(5);
	SMG_All(0xff);
}
void main(void)
{
 	Init_Timer();
	Init_System();
 	while(1)
	{
		SMG_Display_Data();
		Key_Scans();

	}


}

void Server_Timer0 () interrupt 1
{
 	TH0  =(65535-10000)/256; //10ms
	TL0	 =(65535-10000)%256;
	count++;
	if(count == 100)	  //1s
	{
		s_flag = 1;
		count = 0;
	}
}