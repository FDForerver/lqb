#include "reg52.h"
#include "absacc.h"

/********************************************
Date:2022-1-13
Author:С��ͬѧ
Learn From:B վС�۷���ʦ
*********************************************/





void delay(unsigned int t)
{
	unsigned int i,j;
	for(i = 0; i< t;i++)
	{
		for(j = 0; j < 12000;j++);
	}
}


//-----------------------------ϵͳ��ʼ��-----------------------------
void InitSystem(void)
{
 	 XBYTE[0xa000] = 0x00;	//�رշ����� �̵���
	 XBYTE[0x8000] = 0xff; //�ر�LED
}
//----------------------------------------------------------------------


//--------------------------------LED���ܺ���----------------------------
void LedRunning(void)
{
	XBYTE[0x8000] = 0xf0;
	delay(50);
	XBYTE[0x8000]  = 0x0f;
	delay(50);
	P0 = 0xff;
	delay(50);
}


void SMG_Running(void)
{
		 unsigned char i;
		 
		 for(i = 0; i< 8;i++)
		 {
		 		XBYTE[0xc000] = 0x01 << i;
				XBYTE[0xe000] = 0x00;
				delay(10);
		 }
			XBYTE[0xe000] = 0xff;
			delay(10);
}

//------------------------------------------------------------------------



void main(void)
{
	InitSystem();
 	while(1)
	{
		 LedRunning();
		 SMG_Running();

	}


}