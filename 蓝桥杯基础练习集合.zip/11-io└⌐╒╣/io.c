#include "reg52.h"

/********************************************
Date:2022-1-13
Author:С��ͬѧ
Learn From:B վС�۷���ʦ
*********************************************/


//--------------------------74HC138��ʼ��---------------------------
void Init_74HC138(unsigned char n)
{
 	switch(n)
	{
		case 4: P2 = P2 | 0x1f; P2 = 0x80; break;
		case 5: P2 = P2 | 0x1f; P2 = 0xa0; break;
		case 6: P2 = P2 | 0x1f; P2 = 0xc0; break;
		case 7: P2 = P2 | 0x1f; P2 = 0xe0; break; 
	}
}



void delay(unsigned int t)
{
	unsigned int i,j;
	for(i = 0; i< t;i++)
	{
		for(j = 0; j < 12000;j++);
	}
}
//--------------------------------------------------------------------

//-----------------------------ϵͳ��ʼ��-----------------------------
void InitSystem(void)
{
 	 Init_74HC138(5);			//Y5ѡͨ
	 P0 = 0x00; //�رռ̵����ͷ�����
	 Init_74HC138(4);		 //Y4
	 P0 = 0xff; //�ر�LED

}
//----------------------------------------------------------------------


//--------------------------------LED���ܺ���----------------------------
void LedRunning(void)
{
	Init_74HC138(4);
	P0 = 0xf0;
	delay(50);
	P0 = 0x0f;
	delay(50);
	P0 = 0xff;
	delay(50);


}


void SMG_Running(void)
{
		 unsigned char i;
		 
		 for(i = 0; i< 8;i++)
		 {
		 	Init_74HC138(6);
			P0 = 0x01 << i;
			Init_74HC138(7);
			P0 = 0X00;
			delay(10);
			}
			P0 = 0xff;
			delay(10);
}

//------------------------------------------------------------------------



void main(void)
{
	InitSystem();
 	while(1)
	{
		 LedRunning();
		 SMG_Running();

	}


}